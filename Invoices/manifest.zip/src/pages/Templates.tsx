import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, X, Edit, Trash2, Eye, BookTemplate as FileTemplate, Star } from 'lucide-react';
import { templatesApi, Template, companyApi } from '../services/api';
import toast from 'react-hot-toast';

export const Templates: React.FC = () => {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'mine' | 'marketplace'>('mine'); // Nova aba
  const [settingDefaultId, setSettingDefaultId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [previewOpen, setPreviewOpen] = React.useState(false);
  const [previewHtml, setPreviewHtml] = React.useState('');
  const [previewCss, setPreviewCss] = React.useState('');
  const [previewTitle, setPreviewTitle] = React.useState('');
  const [companyCurrency, setCompanyCurrency] = React.useState<string | undefined>(undefined);
const [currentCompanyId, setCurrentCompanyId] = React.useState<string>('');

  React.useEffect(() => {
    const loadCompany = async () => {
      try {
        const profile = await companyApi.getProfile();
        setCompanyCurrency(profile.currency);
        setCurrentCompanyId(profile._id); // ← Armazena o ID do perfil
      } catch (e) {
        console.error('Erro ao carregar perfil:', e);
      }
    };
    loadCompany();
  }, []);

  const getCurrencySymbol = (code?: string) => {
    switch ((code || '').toUpperCase()) {
      case 'USD': return '$';
      case 'EUR': return '€';
      case 'GBP': return '£';
      case 'MZN': return 'MTn';
      default: return code || '';
    }
  };

  useEffect(() => {
    loadTemplates();
  }, [search, activeTab]); // Recarrega ao mudar de aba

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const templatesData = await templatesApi.getAll();
      setTemplates(templatesData);
    } catch (error) {
      console.error('Error loading templates:', error);
      toast.error('Failed to load templates');
    } finally {
      setLoading(false);
    }
  };

  // ====================== FILTRAGEM CORRIGIDA ======================
  const myTemplates = templates.filter(template => {
    // Template pertence à empresa atual OU é built-in
    const templateCompanyId = typeof template.company === 'string' 
      ? template.company 
      : template.company?._id;

    return templateCompanyId === currentCompanyId || template.isBuiltIn === true;
  });

  const marketplaceTemplates = templates.filter(template => 
    template.isPublic === true && 
    (typeof template.company === 'string' 
      ? template.company !== currentCompanyId 
      : template.company?._id !== currentCompanyId)
  );

  const filteredTemplates = (activeTab === 'mine' ? myTemplates : marketplaceTemplates)
    .filter(template =>
      template.name.toLowerCase().includes(search.toLowerCase()) ||
      template.description?.toLowerCase().includes(search.toLowerCase())
    );

  // ====================== HANDLE SET DEFAULT ======================
  const handleSetDefault = async (templateId: string, templateName: string) => {
    if (settingDefaultId) return;

    setSettingDefaultId(templateId);

    try {
      await templatesApi.setDefault(templateId);
      toast.success(`"${templateName}" definido como template padrão!`);

      await loadTemplates();
    } catch (error: any) {
      console.error('Error setting default:', error);
      toast.error(error.response?.data?.message || 'Os templates pagos só poderão ser definidos como padrão após a compra. Por favor, adquira o template para habilitar esta funcionalidade.');
    } finally {
      setSettingDefaultId(null);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this template?')) {
      return;
    }

    try {
      await templatesApi.delete(id);
      toast.success('Template deleted successfully');
      loadTemplates();
    } catch (error) {
      console.error('Error deleting template:', error);
      toast.error('Failed to delete template');
    }
  };

  const buildMockPreview = (template: Template) => {
    const mock = {
      company: {
        name: 'Acme Incorporated',
        email: 'hello@acme.example',
        phone: '+258 84 000 0000',
        address: { street: '123 Main St', city: 'Maputo', state: 'MP', zipCode: '1100' },
        logo: '',
      },
      number: 'INV-0001',
      documentType: 'Invoice',
      subtotal: '1,234.00',
      taxAmount: '123.40',
      total: '1,357.40',
      currencySymbol: getCurrencySymbol(companyCurrency),
    };

    let html = template.htmlContent || '<div style="padding:20px">No content</div>';
    const css = template.cssContent || '';

    html = html.replace(/{{\s*company\.name\s*}}/g, mock.company.name);
    html = html.replace(/{{\s*company\.email\s*}}/g, mock.company.email);
    html = html.replace(/{{\s*company\.phone\s*}}/g, mock.company.phone);
    html = html.replace(/{{\s*company\.address\.street\s*}}/g, mock.company.address.street);
    html = html.replace(/{{\s*number\s*}}/g, mock.number);
    html = html.replace(/{{\s*documentType\s*}}/g, mock.documentType);

    html = html.replace(/{{\s*formatCurrency[^}]*}}/g, `${mock.currencySymbol}${mock.total}`);
    html = html.replace(/{{[^}]*}}/g, '');

    return { html, css };
  };

  const previewTemplate = (template: Template) => {
    try {
      const { html, css } = buildMockPreview(template);
      setPreviewTitle(template.name);
      setPreviewHtml(html);
      setPreviewCss(css);
      setPreviewOpen(true);
    } catch (error) {
      console.error('Preview error:', error);
      toast.error('Failed to prepare preview');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header - Mantido exatamente como estava */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div className="space-y-1">
          <h1 className="text-2xl md:text-3xl font-black text-gray-900 uppercase tracking-tighter">
            Templates
          </h1>
          <p className="text-sm md:text-base text-gray-500 font-medium leading-relaxed max-w-md">
            Gerencie e personalize os seus modelos de documentos.
          </p>
        </div>

        <Link
          to="/templates/new"
          className="w-full sm:w-auto flex items-center justify-center px-6 py-3.5 md:py-2.5 bg-blue-600 text-white rounded-2xl md:rounded-xl text-xs md:text-sm font-black uppercase tracking-widest hover:bg-blue-700 transition-all active:scale-95 shadow-lg shadow-blue-900/10 border border-blue-500/10"
        >
          <Plus className="h-5 w-5 mr-2 shrink-0" />
          Novo Template
        </Link>
      </div>

      {/* === TABS ADICIONADAS === */}
      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setActiveTab('mine')}
          className={`px-6 py-3 font-medium text-sm border-b-2 transition-all ${
            activeTab === 'mine' 
              ? 'border-blue-600 text-blue-600' 
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          Meus Templates
        </button>
        <button
          onClick={() => setActiveTab('marketplace')}
          className={`px-6 py-3 font-medium text-sm border-b-2 transition-all ${
            activeTab === 'marketplace' 
              ? 'border-blue-600 text-blue-600' 
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          Marketplace
        </button>
      </div>

      {/* Search - Mantido igual */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="relative">
          <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search templates..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Templates Grid - Mantido o layout base, apenas com filtragem por aba */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <>
            {filteredTemplates.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
                {filteredTemplates.map((template) => (
                  <div key={template._id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <FileTemplate className="h-5 w-5 text-blue-500 mr-2" />
                          <h3 className="text-lg font-semibold text-gray-900">{template.name}</h3>
                        </div>

                        {/* Badges */}
                        <div className="flex flex-wrap gap-1 mb-3">
                          {template.isDefaultForCurrentCompany && (   // Alterado para usar o campo correto
                            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full flex items-center gap-1">
                              <Star className="h-3 w-3" /> Default
                            </span>
                          )}
                          {template.isBuiltIn && (
                            <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs font-medium rounded-full">
                              Built-in
                            </span>
                          )}
                          {template.isPublic && (
                            <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                              Public
                            </span>
                          )}
                          {template.isPublic && template.isPaid && (
                            <span className="px-2 py-1 bg-yellow-50 text-yellow-800 text-xs font-medium rounded-full">
                              Paid • {template.price}
                            </span>
                          )}
                        </div>

                        {template.description && (
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{template.description}</p>
                        )}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Document Types</p>
                        <div className="flex flex-wrap gap-1">
                          {template.documentTypes.map((type) => (
                            <span
                              key={type}
                              className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-md"
                            >
                              {type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' ')}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-gray-200 flex items-center justify-between text-xs text-gray-500">
                        <span>
                          {template.createdBy 
                            ? `By ${template.createdBy.firstName} ${template.createdBy.lastName}` 
                            : 'By system'}
                        </span>

                        <button
                          onClick={() => previewTemplate(template)}
                          className="flex items-center text-blue-600 hover:text-blue-800"
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          Preview
                        </button>
                      </div>
                    </div>

                    {/* Actions - Mantido igual */}
                    <div className="flex gap-2 mt-5 pt-4 border-t border-gray-100">
                      {!template.isBuiltIn && (
                        <button
                          onClick={() => handleSetDefault(template._id, template.name)}
                          disabled={settingDefaultId === template._id || template.isDefaultForCurrentCompany}
                          className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium rounded-xl transition-all
                            ${template.isDefaultForCurrentCompany 
                              ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                              : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
                        >
                          <Star className="h-4 w-4" />
                          {settingDefaultId === template._id 
                            ? 'Definindo...' 
                            : template.isDefaultForCurrentCompany 
                              ? 'Já é Default' 
                              : 'Set as Default'}
                        </button>
                      )}

                      {!template.isBuiltIn && (
                        <>
                          <Link
                            to={`/templates/${template._id}/edit`}
                            className="p-3 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-xl transition-colors"
                          >
                            <Edit className="h-4 w-4" />
                          </Link>

                          <button
                            onClick={() => handleDelete(template._id)}
                            className="p-3 text-gray-500 hover:text-red-600 hover:bg-gray-100 rounded-xl transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileTemplate className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No templates found</h3>
                <p className="mt-1 text-sm text-gray-500">
                  {search 
                    ? 'Try adjusting your search criteria.' 
                    : activeTab === 'mine' 
                      ? 'Você ainda não tem templates próprios.' 
                      : 'Nenhum template disponível no marketplace.'}
                </p>
                <div className="mt-6">
                  <Link
                    to="/templates/new"
                    className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    New Template
                  </Link>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Preview Modal - Mantido exatamente como estava */}
      {previewOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-6">
          <div className="fixed inset-0 bg-black opacity-40" onClick={() => setPreviewOpen(false)} />
          <div className="relative w-full max-w-4xl bg-white rounded-lg shadow-lg overflow-auto" style={{ maxHeight: '90vh', zIndex: 60 }}>
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">{previewTitle} — Preview</h3>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">{companyCurrency ? companyCurrency : ''}</span>
                <button onClick={() => setPreviewOpen(false)} className="p-2 hover:bg-gray-100 rounded">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="p-4">
              <div
                className="border rounded overflow-hidden"
                style={{ minHeight: 300 }}
              >
                <style>{previewCss}</style>
                <div dangerouslySetInnerHTML={{ __html: previewHtml }} />
              </div>

              <div className="mt-3 text-sm text-gray-500">
                Esta é uma pré-visualização simulada com dados mock (nome da empresa, cliente, números e valores fictícios). Valores de moeda usam o código da empresa exibido acima.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};