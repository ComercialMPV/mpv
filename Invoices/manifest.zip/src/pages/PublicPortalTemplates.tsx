import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Edit, Eye, Trash2, X, Globe, Code, Copy, Settings } from 'lucide-react';
import toast from 'react-hot-toast';
import { publicPortalTemplatesApi } from '../services/api';
import { PUBLIC_PORTAL_VARIANTS, PortalVariantId } from '../config/public-portal-variants';
import { useAuth } from '../contexts/AuthContext'; // ajuste o caminho se necessário

type PreviewState = {
  open: boolean;
  template?: any;
  Component?: React.ComponentType<any> | null;
};

export const PublicPortalTemplates: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [templates, setTemplates] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [preview, setPreview] = useState<PreviewState>({ open: false, Component: null });

  const isAdmin = user && 
    (
      user.role === 'admin' || 
      user.role === 'owner' || 
      user.role === 'superadmin' ||
      (typeof user.role === 'object' &&
        (
          user.role.roleName === 'admin' ||
          user.role.roleName === 'owner' ||
          user.role.roleName === 'superadmin'
        )
      )
    );
  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const data = await publicPortalTemplatesApi.getAll();
      setTemplates(data);
    } catch (err) {
      console.error('Error loading public portal templates', err);
      toast.error('Failed to load templates');
    } finally {
      setLoading(false);
    }
  };

  const filteredTemplates = templates.filter(template =>
    template.name.toLowerCase().includes(search.toLowerCase()) ||
    template.description?.toLowerCase().includes(search.toLowerCase())
  );

  const handleEdit = (id: string) => {
    // Built-in variants cannot be edited directly, but can be used as base
    if (id.startsWith('builtin-')) {
      toast.info('Built-in templates cannot be edited. Create a custom variant instead.');
      return;
    }
    navigate(`/public-portal-templates/${id}/edit`);
  };

  const handleCreate = () => {
    navigate('/public-portal-templates/new');
  };

  const handleDelete = async (id: string) => {
    // Cannot delete built-in templates
    if (id.startsWith('builtin-')) {
      toast.error('Cannot delete built-in templates');
      return;
    }

    if (!confirm('Are you sure you want to delete this template?')) return;
    try {
      await publicPortalTemplatesApi.delete(id);
      toast.success('Template deleted successfully');
      loadTemplates();
    } catch (e) {
      console.error(e);
      toast.error('Failed to delete template');
    }
  };

  const handlePreview = async (t: any) => {
    setPreview({ open: true, template: t, Component: null });
    if (t.templateType === 'variant') {
      try {
        const variant = PUBLIC_PORTAL_VARIANTS.find(v => v.id === t.variantId);
        if (!variant) return toast.error('Variant not found');
        if (!('component' in variant)) return toast.error('Variant does not have a component');
        const mod: any = await variant.component();
        const Comp = mod.default || mod;
        setPreview({ open: true, template: t, Component: Comp });
      } catch (err) {
        console.error('Failed to load variant', err);
        toast.error('Failed to load variant');
      }
    }
  };

  const closePreview = () => setPreview({ open: false, Component: null });

  const getVariantName = (variantId: PortalVariantId | string) => {
    const variant = PUBLIC_PORTAL_VARIANTS.find(v => v.id === variantId);
    return variant?.name || variantId;
  };

  const handleDuplicateBuiltIn = async (template: any) => {
    try {
      const newTemplate = {
        name: `${template.name} (Copy)`,
        description: template.description,
        htmlContent: template.htmlContent || '',
        cssContent: template.cssContent || '',
        logoOverride: template.logoOverride || '',
        primaryColor: template.primaryColor || '#3b82f6',
        accentColor: template.accentColor || '#1e40af',
        templateType: template.templateType,
        variantId: template.variantId,
        isPublic: false,
        isPaid: false,
        price: 0,
      };

      const created = await publicPortalTemplatesApi.create(newTemplate);
      toast.success('Template duplicated! Now customizing your copy.');
      navigate(`/public-portal-templates/${created._id}/edit`);
    } catch (e) {
      console.error(e);
      toast.error('Failed to duplicate template');
    }
  };
  const handleManageBuiltIn = () => {
    navigate('/builtin-variants');
  };

  // Se ainda está a carregar autenticação → mostra skeleton ou nada
  if (authLoading) {
    return <div className="p-8 text-center">A carregar...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        {/* Lado Esquerdo: Identidade da Secção */}
        <div className="space-y-1">
          <h1 className="text-2xl md:text-3xl font-black text-gray-900 uppercase tracking-tighter">
            Portal Templates
          </h1>
          <p className="text-sm md:text-base text-gray-500 font-medium leading-relaxed max-w-md">
            Create and manage public portal variants. Choose from built-in React components or custom HTML templates.
          </p>
        </div>

        {/* Lado Direito: Ação Principal */}
        <button
          onClick={handleCreate}
          className="w-full sm:w-auto flex items-center justify-center px-6 py-3.5 md:py-2.5 bg-blue-600 text-white rounded-2xl md:rounded-xl text-xs md:text-sm font-black uppercase tracking-widest hover:bg-blue-700 transition-all active:scale-95 shadow-lg shadow-blue-900/10 border border-blue-500/10"
        >
          <Plus className="h-5 w-5 mr-2 shrink-0" />
          New Template
        </button>
      </div>
{/* Cabeçalho com título + botão admin (condicional) */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Templates de Portal Público</h1>
          <p className="text-gray-600 mt-1">
            Escolha ou personalize o layout do portal de solicitação de serviços
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          {isAdmin && (
            <button
              onClick={handleManageBuiltIn}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors shadow-sm"
            >
              <Settings className="h-4 w-4" />
              Gerir Variantes Built-in
            </button>
          )}

          <button
            onClick={handleCreate}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
          >
            <Plus className="h-4 w-4" />
            Criar Template Personalizado
          </button>
        </div>
      </div>
      {/* Search */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="relative">
          <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search templates..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Templates Grid */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <>
            {filteredTemplates.length > 0 ? (
              <>
                {/* Built-in Templates Section */}
                {filteredTemplates.some(t => t.isBuiltIn) && (
                  <div className="border-b border-gray-200 p-6">
                    <div className="mb-4">
                      <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                        <span className="text-2xl">⭐</span> Built-in Variants
                      </h2>
                      <p className="text-sm text-gray-600 mt-2">
                        These default templates are always available and cannot be edited. They come from your local Portal Variants configuration.
                      </p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredTemplates.filter(t => t.isBuiltIn).map((template) => (
                        <div key={template._id} className="border border-yellow-200 bg-yellow-50 rounded-lg p-6 hover:shadow-md transition-shadow">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <div className="flex flex-wrap items-center gap-2 mb-2">
                                {template.templateType === 'variant' ? (
                                  <Globe className="h-5 w-5 text-purple-600" />
                                ) : (
                                  <Code className="h-5 w-5 text-blue-600" />
                                )}
                                <h3 className="text-lg font-semibold text-gray-900">{template.name}</h3>
                              </div>
                              <p className="text-sm text-gray-700 mb-3">{template.description}</p>
                              <div className="flex flex-wrap gap-2">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-yellow-200 text-yellow-900">
                                  Built-in
                                </span>
                                {template.templateType === 'variant' && (
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                    React: {getVariantName(template.variantId)}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="mt-4 pt-4 border-t border-yellow-200 flex items-center md:flex-wrap sm:flex-wrap justify-between gap-2">
                            <button
                              onClick={() => handlePreview(template)}
                              className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            >
                              <Eye className="h-4 w-4" />
                              Preview
                            </button>
                            <button
                              onClick={() => handleDuplicateBuiltIn(template)}
                              className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-green-700 border border-green-300 hover:bg-green-50 rounded-lg transition-colors"
                            >
                              <Copy className="h-4 w-4" />
                              Duplicate
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Custom Templates Section */}
                {filteredTemplates.some(t => !t.isBuiltIn) && (
                  <div className="p-6">
                    <div className="mb-4">
                      <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                        <span className="text-2xl">📦</span> Custom Templates
                      </h2>
                      <p className="text-sm text-gray-600 mt-2">
                        Templates you created or imported. You can edit and delete these freely.
                      </p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredTemplates.filter(t => !t.isBuiltIn).map((template) => (
                        <div key={template._id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <div className="flex flex-wrap items-center gap-2 mb-2">
                                {template.templateType === 'variant' ? (
                                  <Globe className="h-5 w-5 text-purple-500" />
                                ) : (
                                  <Code className="h-5 w-5 text-blue-500" />
                                )}
                                <h3 className="text-lg font-semibold text-gray-900">{template.name}</h3>
                              </div>
                              <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                              <div className="flex flex-wrap gap-2">
                                {template.templateType === 'html' && (
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    HTML
                                  </span>
                                )}
                                {template.templateType === 'variant' && (
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                    React Variant
                                  </span>
                                )}
                                {template.isPublic && !template.isPaid && (
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 text-indigo-800">
                                    Free Public
                                  </span>
                                )}
                                {template.isPublic && template.isPaid && (
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-800">
                                    Paid (MT {template.price})
                                  </span>
                                )}
                                {!template.isPublic && (
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                                    Private
                                  </span>
                                )}
                                {template.templateType === 'variant' && (
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                                    {getVariantName(template.variantId)}
                                  </span>
                                )}
                              </div>
                            </div>
                            <button
                              onClick={() => handleDelete(template._id)}
                              className="ml-2 p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              title="Delete template"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                          <div className="mt-4 pt-4 border-t border-gray-200 flex items-center justify-between gap-2">
                            <div className="flex-1 flex gap-2">
                              <button
                                onClick={() => handlePreview(template)}
                                className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                              >
                                <Eye className="h-4 w-4" />
                                Preview
                              </button>
                              <button
                                onClick={() => handleEdit(template._id)}
                                className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 border border-gray-300 hover:bg-gray-50 rounded-lg transition-colors"
                              >
                                <Edit className="h-4 w-4" />
                                Edit
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-64">
                <p className="text-gray-500 mb-4">No templates found</p>
                <button
                  onClick={handleCreate}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Plus className="h-4 w-4" />
                  Create First Template
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Preview Modal */}
      {preview.open && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-6 bg-black bg-opacity-50">
          <div className="bg-white rounded-xl w-full max-w-6xl max-h-[90vh] overflow-auto shadow-2xl">
            <div className="sticky top-0 bg-white p-6 border-b border-gray-200 flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Preview</h3>
                <p className="text-sm text-gray-600 mt-1">{preview.template?.name}</p>
              </div>
              <button
                onClick={closePreview}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6">
              {preview.template?.templateType === 'variant' ? (
                preview.Component ? (
                  <div className="border rounded-lg overflow-hidden bg-gray-50 min-h-[400px]">
                    <preview.Component company={{ name: 'Empresa Exemplo', logo: '' }} />
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-64">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                      <p className="text-gray-600">Loading variant...</p>
                    </div>
                  </div>
                )
              ) : (
                <div className="border rounded-lg overflow-hidden bg-white">
                  <style>{preview.template?.cssContent || ''}</style>
                  <div
                    className="p-6"
                    dangerouslySetInnerHTML={{
                      __html: (preview.template?.htmlContent || '')
                        .replace(/{{company\.name}}/g, 'Empresa Exemplo')
                        .replace(/{{primaryColor}}/g, preview.template?.primaryColor || '#3b82f6')
                        .replace(/{{accentColor}}/g, preview.template?.accentColor || '#1e40af'),
                    }}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
