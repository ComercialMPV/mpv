import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import toast from 'react-hot-toast';
import { useAuth } from '../contexts/AuthContext';
import { 
  Wallet, 
  CreditCard, 
  Key, 
  Save, 
  Loader2, 
  Info,
  Smartphone,
  CheckCircle2
} from 'lucide-react';

interface WalletIds {
  mpesa: string;
  emola: string;
  visa: string;
  debitoPat: string;
}

export const PaymentsSettings: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const [wallets, setWallets] = useState<WalletIds>({
    mpesa: '',
    emola: '',
    visa: '',
    debitoPat: '',
  });

  const [saving, setSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const initialWalletsRef = useRef<WalletIds | null>(null);

  const defaults = {
    mpesa: import.meta.env.VITE_MPESA_WALLET || '',
    emola: import.meta.env.VITE_EMOLA_WALLET || '',
    visa: import.meta.env.VITE_VISA_WALLET || '',
    debitoPat: import.meta.env.VITE_DEBITO_PAT || '',
  };

  useEffect(() => {
    if (!user) return;
    const userWallets = user.walletIds || {};
    const loaded = {
      mpesa: userWallets.mpesa ?? defaults.mpesa,
      emola: userWallets.emola ?? defaults.emola,
      visa: userWallets.visa ?? defaults.visa,
      debitoPat: userWallets.debitoPat ?? defaults.debitoPat,
    };
    setWallets(loaded);
    initialWalletsRef.current = loaded;
    setHasChanges(false);
  }, [user]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setWallets((prev) => {
      const updated = { ...prev, [name]: value };
      if (initialWalletsRef.current) {
        const changed = Object.keys(updated).some(
          (key) => updated[key as keyof WalletIds] !== initialWalletsRef.current![key as keyof WalletIds]
        );
        setHasChanges(changed);
      }
      return updated;
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?._id) return;
    setSaving(true);

    try {
      const payload = {
        walletIds: {
          mpesa: wallets.mpesa.trim(),
          emola: wallets.emola.trim(),
          visa: wallets.visa.trim(),
          debitoPat: wallets.debitoPat.trim(),
        },
      };

      await api.users.update(user._id, payload);
      toast.success('Configurações atualizadas com sucesso!');
      await refreshUser?.();
      setHasChanges(false);
    } catch (err: any) {
      toast.error('Erro ao guardar configurações.');
    } finally {
      setSaving(false);
    }
  };

  const walletFields = [
    { id: 'mpesa', label: 'M-Pesa ID', icon: Smartphone, color: 'text-red-600', placeholder: '84XXXXXXX' },
    { id: 'emola', label: 'e-Mola ID', icon: Smartphone, color: 'text-orange-500', placeholder: '86XXXXXXX' },
    { id: 'visa', label: 'VISA/Mastercard ID', icon: CreditCard, color: 'text-blue-600', placeholder: '569596' },
  ];

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto pb-10">
      <div className="mb-8">
        <h1 className="text-2xl font-black text-slate-900 flex items-center gap-2">
          <Wallet className="text-blue-600" />
          Configurações de Pagamento
        </h1>
        <p className="text-slate-500 mt-1">
          Gira as suas carteiras digitais e chaves de integração para receber pagamentos dos seus clientes.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Seção 1: Carteiras Móveis e Cartões */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 bg-slate-50/50">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Smartphone size={18} />
              Recebimento Direto (Wallets)
            </h3>
          </div>
          
          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            {walletFields.map((field) => (
              <div key={field.id} className="space-y-2">
                <label className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <field.icon size={14} className={field.color} />
                  {field.label}
                </label>
                <input
                  name={field.id}
                  type="text"
                  value={wallets[field.id as keyof WalletIds]}
                  onChange={handleChange}
                  placeholder={field.placeholder}
                  className="w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all outline-none font-medium"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Seção 2: API & Segurança */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 bg-slate-50/50">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Key size={18} />
              Integração Débito PAT
            </h3>
          </div>
          
          <div className="p-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="flex-1 w-full space-y-2">
                <label className="text-xs font-black uppercase tracking-wider text-slate-500">
                  Token de Autorização (Private Key)
                </label>
                <div className="relative">
                  <input
                    name="debitoPat"
                    type="password"
                    value={wallets.debitoPat}
                    onChange={handleChange}
                    placeholder="Introduza o seu Token do Débito PAT"
                    className="w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all outline-none font-mono"
                  />
                  <div className="absolute inset-y-0 right-3 flex items-center text-slate-400">
                    <Key size={16} />
                  </div>
                </div>
              </div>

              <div className="w-full md:w-72 bg-blue-50 rounded-2xl p-4 border border-blue-100">
                <div className="flex gap-3">
                  <Info className="text-blue-600 shrink-0" size={18} />
                  <p className="text-xs text-blue-800 leading-relaxed">
                    Este token permite que o sistema processe pagamentos em seu nome. Mantenha-o seguro e não o partilhe.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Barra de Ações Flutuante ou Fixa */}
        <div className="flex items-center justify-between bg-slate-900 p-4 rounded-2xl shadow-xl shadow-slate-200">
          <div className="hidden md:flex items-center gap-3 text-slate-400 ml-2">
            {hasChanges ? (
              <div className="flex items-center gap-2 text-amber-400 text-sm animate-pulse">
                <div className="w-2 h-2 rounded-full bg-amber-400" />
                Alterações não guardadas
              </div>
            ) : (
              <div className="flex items-center gap-2 text-emerald-400 text-sm">
                <CheckCircle2 size={16} />
                Tudo atualizado
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={saving || !hasChanges}
            className={`
              relative flex items-center gap-2 px-8 py-3 rounded-xl text-sm font-bold transition-all
              ${!hasChanges || saving 
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                : 'bg-blue-600 text-white hover:bg-blue-500 active:scale-95 shadow-lg shadow-blue-900/20'}
            `}
          >
            {saving ? (
              <Loader2 className="animate-spin" size={18} />
            ) : (
              <Save size={18} />
            )}
            {saving ? 'A guardar...' : 'Guardar Alterações'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PaymentsSettings;