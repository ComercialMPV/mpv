// src/templates/public-portal/variants/CuidadorPortal.tsx
import React, { useState, useEffect, useMemo } from 'react';
import { Service, Company, Product, Bundle, API_BS_URL} from '../../../services/api';
import {
  User, FileText,  Package, Menu, Lock, ArrowRight, ArrowLeft, ArrowUpRight, Layers, Settings, Utensils, Briefcase, PhoneCall, Heart, ChevronDown, ShoppingBag, ChevronLeft, ChevronRight, Play,Plus, Trash2,
  CheckCircle, Info, CreditCard, UtensilsCrossed, ShoppingCart, X,
  Search, Calendar, Minus, Check, User2, Eye,
  Zap,
  Linkedin,
  Instagram,
  Facebook,
  Leaf,
  Target,
  ShieldCheck,
  Star,
  Quote
} from 'lucide-react';
import toast from 'react-hot-toast';
import { api } from '../../../services/api';

const SERVER_BASE_URL = import.meta.env.VITE_API_BS_URL || 'http://localhost:5000';

// Helper function to convert relative paths to absolute URLs
const getImageUrl = (imagePath: string): string => {
  if (!imagePath) return '';
  if (imagePath.startsWith('http')) return imagePath; // Already absolute
  return `${SERVER_BASE_URL}${imagePath}`; // Convert relative to absolute
};

interface CuidadorProps {
  company: Company;
  slug: string;
  services: Service[];
  products?: Product[];
  bundles?: Bundle[];
  portalContent?: any;
}

type CatalogType = 'services' | 'products' | 'bundles';

type CartItem = {
  itemId: string;
  type: CatalogType;
  quantity: number;
  name: string;
  price: number;
  image?: string;
  madeToOrder?: boolean;     // ← deve existir
  orderPrice?: number;       // ← deve existir
  deliveryDays?: number;     // ← deve existir
  wantsOrder?: boolean;      // ← já tens
};

interface ClientInfo {
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  taxId: string;
  vatNumber?: string;
  billingAddress: {
    street: string;
    city: string;
    country: string;
  };
}

const CuidadorPortal: React.FC<CuidadorProps> = ({ 
  company, 
  slug, 
  services: initialServices,
  products: initialProducts,
  bundles: initialBundles,
  portalContent = {
    hero: {
      headline: "Home Care Serviços",
      subheadline: "Serviços de Recrutamento, Treinamento e Intermediação de Profissionais Domésticos",
      backgroundImage: "https://i.pinimg.com/736x/65/9a/a2/659aa2282572a132c9fa145f166f07da.jpg"
    },
    about: {
      enabled: true,
      title: "Ajudando famílias a encontrar os melhores cuidadores de lar",
      body: "<p>Treinamento e intermediação de profissionais domésticos.</p>",
      image: "https://i1-c.pinimg.com/736x/3d/bb/21/3dbb21d2806caf3f93b04aa6457af482.jpg"
    },
    missionVision: {
      enabled: true,
      mission: { title: "Our Mission", content: "Deliver excellence in legal services" },
      vision: { title: "Our Vision", content: "Lead the legal industry with innovation" },
      values: { title: "Our Values", items: ["Integrity", "Excellence", "Client Focus"] }
    },
    clients: { enabled: true, items: [] },
    testimonials: { enabled: true, items: [] }
  },
}) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCatalog, setActiveCatalog] = useState<CatalogType>('services');
  const [searchTerm, setSearchTerm] = useState('');
  const [services, setServices] = useState<Service[]>(initialServices || []);

  // will calculate available catalogs once services/products/bundles are defined later

  // track searches performed by visitors (debounced so we don't spam the API)
   // logging de pesquisa já não depende de activeCatalog
  useEffect(() => {
    if (!searchTerm || !slug) return;
   const handler = setTimeout(async () => {
  try {
    await api.public.logSearch(slug, { term: searchTerm, catalog: 'all' });
    console.log(`✅ Pesquisa registrada: "${searchTerm}"`);
  } catch (err) {
    console.error('❌ Falha ao registrar busca:', err);
  }
}, 500);
    return () => clearTimeout(handler);
  }, [searchTerm, slug]);

  const [products, setProducts] = useState<Product[]>(initialProducts || []);
  const [bundles, setBundles] = useState<Bundle[]>(initialBundles || []);

  // compute which catalogs currently have items
  const availableCatalogs: CatalogType[] = React.useMemo(() => {
    const list: CatalogType[] = [];
    if (services && services.length > 0) list.push('services');
    if (products && products.length > 0) list.push('products');
    if (bundles && bundles.length > 0) list.push('bundles');
    return list;
  }, [services, products, bundles]);

 useEffect(() => {
  console.log("Company data received:", {
    hasBankAccounts: !!company?.bankAccounts?.length,
    hasMobileWallets: !!company?.mobileWallets,
    bankAccounts: company?.bankAccounts,
    mobileWallets: company?.mobileWallets
  });
}, [company]);

  // ensure activeCatalog is always one of the available ones when data changes
  useEffect(() => {
    if (availableCatalogs.length === 0) return;
    if (!availableCatalogs.includes(activeCatalog)) {
      setActiveCatalog(availableCatalogs[0]);
    }
  }, [availableCatalogs, activeCatalog]);

  const [submitting, setSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any | null>(null);
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [isSearchOpen, setIsSearchOpen] = useState(false);


  const [client, setClient] = useState<ClientInfo>({
    name: '',
    contactPerson: '',
    email: '',
    phone: '',
    taxId: '',
    vatNumber: '',
    billingAddress: { street: '', city: '', country: 'Moçambique' }
  });

  const [requestedInstallments, setRequestedInstallments] = useState(1);
  const [deliveryDate, setDeliveryDate] = useState('');
  const [requestIntent, setRequestIntent] = useState<'quotation' | 'invoice'>('quotation');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'mpesa'|'emola'|'visa'|'transfer'|'none'>('none');
const [visibleServices, setVisibleServices] = useState(3);
const [currentImgIndex, setCurrentImgIndex] = useState(0);
  const currency = company.currency || 'MT';

    // ------------ alterações -------------
  // controla o “ver mais” de cada secção
  const [showAllProducts, setShowAllProducts] = useState(false);


  // guarda o tipo do item que está aberto no modal (usado mais abaixo)
  const [selectedItemType, setSelectedItemType] = useState<CatalogType | null>(null);

  const openItem = (item: any, type: CatalogType) => {
    setSelectedItem(item);
    setSelectedItemType(type);
    setCarouselIndex(0);
  };

    // listas filtradas individualmente
  const filteredProducts = products.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (item.description?.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  const filteredServices = services.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (item.description?.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  const filteredBundles = bundles.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (item.description?.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (item.shortDescription?.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Only load if initial data is not provided (public portal provides all data)
 useEffect(() => {
  if (initialServices?.length && initialProducts?.length && initialBundles?.length) {
    return;
  }
  
  const loadCatalog = async () => {
    try {
      const promises = [];
      if (!initialServices?.length) promises.push(api.services.getAll());
      if (!initialProducts?.length) promises.push(api.products.getAll());
      if (!initialBundles?.length) promises.push(api.bundles.getAll());
      
      if (promises.length === 0) return;
      
      const results = await Promise.all(promises);
      console.log("Produtos vindos da API:", results[1]);
      // LOGS DE DEPURAÇÃO
      console.log("--- Resposta Bruta da API ---");
      console.log("Serviços:", results[0]);
      console.log("Produtos:", results[1]);
      console.log("Bundles (Combos/Subs):", results[2]);
      
      // Verifica se os campos esperados existem dentro do primeiro bundle (se houver)
      if (results[2] && results[2].length > 0) {
        console.log("Estrutura do primeiro Bundle:", results[2][0]);
        console.log("Itens populados?", results[2][0].items);
      }

      if (!initialServices?.length && results[0]) setServices(results[0]);
      if (!initialProducts?.length && results[1]) setProducts(results[1]);
      if (!initialBundles?.length && results[2]) setBundles(results[2]);
      
    } catch (err) {
      console.error('Erro detalhado ao carregar catálogo:', err);
    }
  };
  loadCatalog();
}, []);
  // Reset carousel index whenever a new item is selected
  useEffect(() => {
    setCarouselIndex(0);
  }, [selectedItem]);

 const total = useMemo(() => {
  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  
  // Calculamos quanto custa apenas as taxas de encomenda (se houver)
  const orderFeesTotal = cart.reduce((acc, item) => {
    if (item.wantsOrder && item.orderPrice) {
      return acc + (Number(item.orderPrice) * item.quantity);
    }
    return acc;
  }, 0);

  // Se houver qualquer item com taxa de encomenda ativa, o Grand Total vira apenas o valor das taxas
  // Caso contrário, é o subtotal normal.
  const isPayingFees = cart.some(item => item.wantsOrder && Number(item.orderPrice) > 0);
  const grandTotal = isPayingFees ? orderFeesTotal : subtotal;

  return { subtotal, orderFeesTotal, grandTotal, isPayingFees };
}, [cart]);



  // Image helper (products & bundles have real images, services use placeholder – add image field to Service later)
  const getItemImage = (item: any, type: CatalogType): string | undefined => {
    // Products and bundles keep previous logic. For services, prefer real images from DB if available.
    if (type === 'products' && item.images?.length > 0) return getImageUrl(item.images[0]);
    if (type === 'bundles' && item.image) return getImageUrl(item.image);
    if (type === 'services' && item.images?.length > 0) return getImageUrl(item.images[0]);
    return undefined;
  };

  const getItemPrice = (item: any): number => {
  if (!item) return 0;

  const price = 
    item.billingPricePerCycle ?? 
    item.basePrice ?? 
    item.price ?? 
    0;

  // Debug opcional (remove depois de testar)
  // console.log(`getItemPrice for "${item.name}" (type: ${item.type || 'unknown'}):`, price);

  return Number(price);
};

  function getItemDescription(item: any): string {
    return 'shortDescription' in item ? (item as any).shortDescription || '' :
      ('description' in item ? (item as any).description || '' : '');
  }

  // Cart actions
const addToCart = (item: any, type: CatalogType) => {
  // Proteção contra stock zero (exceto madeToOrder)
  if (item.stockQuantity <= 0 && !item.madeToOrder) {
    toast.error(`Produto ${item.name} sem stock disponível`);
    return;
  }

  const existingIndex = cart.findIndex(c => c.itemId === item._id);

  if (existingIndex !== -1) {
    const updated = [...cart];
    updated[existingIndex].quantity += 1;
    setCart(updated);
  } else {
    setCart([...cart, {
      itemId: item._id,
      type,
      quantity: 1,
      name: item.name,
      price: getItemPrice(item),
      image: getItemImage(item, type),

      // === CAMPOS CRUCIAIS PARA MADE TO ORDER ===
      madeToOrder: item.madeToOrder, 
    orderPrice: item.orderPrice,
    deliveryDays: item.deliveryDays,
      wantsOrder: false,                          // começa desmarcado
    }]);
  }

  toast.success(`${item.name} adicionado ao carrinho`, { position: 'top-center' });
};

   const hasOrderWithPrice = cart.some(item => 
  item.wantsOrder === true && Number(item.orderPrice || 0) > 0
);

  const updateCartQuantity = (itemId: string, newQty: number) => {
    if (newQty < 1) return;
    setCart(cart.map(item => item.itemId === itemId ? { ...item, quantity: newQty } : item));
  };

  const removeFromCart = (itemId: string) => {
    setCart(cart.filter(item => item.itemId !== itemId));
  };

  // Totals (exactly your original logic)
  const calculateTotals = () => {
    let subtotal = 0;
    let minAllowed = 99;
    let maxPenaltyPct = 0;

    cart.forEach(cartItem => {
      subtotal += cartItem.price * cartItem.quantity;
      const svc = services.find(s => s._id === cartItem.itemId);
      if (svc) {
        minAllowed = Math.min(minAllowed, svc.allowedInstallments || 3);
        maxPenaltyPct = Math.max(maxPenaltyPct, svc.penaltyPercentagePerInstallment || 0);
      }
    });

    let penalty = 0;
    if (requestedInstallments > minAllowed) {
      const extra = requestedInstallments - minAllowed;
      penalty = subtotal * (extra * (maxPenaltyPct / 100));
    }

    return { subtotal, penalty, grandTotal: subtotal + penalty };
  };

  const totals = calculateTotals();

  // Dynamic max installments (your original logic)
  const getMaxAllowedInstallments = (): number => {
    let minAllowed = Infinity;
    let hasService = false;
    cart.forEach(cartItem => {
      const svc = services.find(s => s._id === cartItem.itemId);
      if (svc) {
        hasService = true;
        minAllowed = Math.min(minAllowed, svc.allowedInstallments || 3);
      }
    });
    return hasService ? Math.max(1, minAllowed) : 12;
  };

  const hasValidItems = cart.length > 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasValidItems) {
      toast.error('Adicione pelo menos um item ao carrinho');
      return;
    }
    if (!client.name || !client.email) {
      toast.error('Nome da empresa e email são obrigatórios');
      return;
    }

    setSubmitting(true);

    try {
     // Dentro de handleSubmit, substitui o payload por:
      const payload = {
        companyId: company._id,
        clientData: { ...client, origin: 'external' },
        requisitionData: {
          items: cart.map(cartItem => ({
            itemType: cartItem.type === 'services' ? 'service' : 
                      cartItem.type === 'products' ? 'product' : 'bundle',
            item: cartItem.itemId,
            isMadeToOrder: cartItem.wantsOrder,
            priceAtOrder: cartItem.price,
            feePaid: cartItem.wantsOrder ? cartItem.orderPrice : 0,
            quantity: cartItem.quantity
          })),
          paymentMethod,
          totalAmount: total.subtotal,
          amountPaid: total.isPayingFees ? total.orderFeesTotal : 0,
          requestedInstallments,
          deliveryDate,
          requestIntent,
          notes
        }
      };

      await api.requisitions.submitPublic(payload);

      setShowSuccessModal(true);
      toast.success('Requisição enviada com sucesso!');

      // Reset everything
      setCart([]);
      setClient({
        name: '', contactPerson: '', email: '', phone: '', taxId: '', vatNumber: '',
        billingAddress: { street: '', city: '', country: 'Moçambique' }
      });
      setRequestedInstallments(1);
      setDeliveryDate('');
      setRequestIntent('quotation');
      setNotes('');
      setIsCartOpen(false);
    } catch (err: any) {
      toast.error(err.message || 'Falha ao enviar');
    } finally {
      setSubmitting(false);
    }
  };
useEffect(() => {
  if (selectedItem?.items) {
    console.log("ESTRUTURA FINAL NO FRONTEND:", JSON.stringify(selectedItem.items, null, 2));
  }
}, [selectedItem]);
 const handlePayment = async () => {
  if (!paymentMethod || paymentMethod === 'none') {
    toast.error('Selecione um método de pagamento');
    return;
  }
  if (!hasValidItems) {
    toast.error('Adicione pelo menos um item ao carrinho');
    return;
  }
  if (!client.name || !client.email) {
    toast.error('Preencha o nome e email para processar o pagamento');
    return;
  }

  setSubmitting(true);
  try {
    const payload = {
      totalAmount: totals.grandTotal,
      method: paymentMethod,
      customer: {
        name: client.name,
        phone: client.phone,
        email: client.email,
      },
      companyId: company._id,
      items: cart.map(ci => ({
        itemId: ci.itemId,
        name: ci.name,
        quantity: ci.quantity,
        price: ci.price,
        type: ci.type
      }))
    };

    const resp = await api.checkout.process(payload, true); // public

    console.log('✅ Resposta do checkout:', resp); // ← Debug importante

    if (resp?.success) {
      if (resp.url) {
        // Redireciona para a página de pagamento (Emola, M-Pesa, Visa)
        window.location.href = resp.url;
      } else {
        // Caso raro onde o pagamento foi concluído imediatamente
        toast.success(resp.message || 'Pagamento processado com sucesso!');
        // Redirecionar para página de sucesso
        setTimeout(() => {
          window.location.href = `/order-success?ref=${resp.externalRef}`;
        }, 1500);
      }
    } else {
      toast.error(resp?.message || 'Não foi possível iniciar o pagamento');
    }
  } catch (err: any) {
    console.error('Payment error:', err);
    
    // Tratamento específico para timeout 504 do Débito
    if (err.message?.includes('504') || err.response?.status === 504) {
      toast.error('O serviço de pagamento está demorando muito. Tente novamente.');
    } else {
      toast.error(err.message || 'Erro ao processar pagamento');
    }
  } finally {
    setSubmitting(false);
  }
};

  const closeSuccessModal = () => setShowSuccessModal(false);

  return (
    <div className="min-h-screen bg-white/5 text-slate-900 font-sans">
      {/* Modern Navbar */}
  
{/* Header Estilo Premium Salon */}
<div className="font-sans text-white bg-black selection:bg-white/30 min-h-screen">
            {/* 1. HEADER REFEITO COM PESQUISA INTEGRADA E CARRINHO */}
<header className=" sticky top-0 w-full z-[60] bg-[#f8f7f2] py-4">
  {/* Top Banner */}
  <div className="w-full bg-[#0E7D83] py-2 text-center text-[10px] text-white/80 uppercase tracking-widest mb-4">
    Subscribe to our Newsletter for latest collections ↗
  </div>

  <div className="max-w-[1440px] mx-auto px-6 flex justify-between items-center relative">
    
    {/* Navegação Esquerda (Esconde quando a busca abre em telas pequenas) */}
    <nav className={`flex items-center gap-2 transition-opacity duration-300 ${isSearchOpen ? 'opacity-0 pointer-events-none lg:opacity-100' : 'opacity-100'}`}>
      {['Home', 'Contribution', 'Our Mission'].map((item) => (
        <a key={item} href={`#${item.toLowerCase()}`} className="px-5 py-2 bg-white rounded-full text-[13px] font-medium text-gray-700 hover:bg-gray-100 transition-all border border-gray-100 whitespace-nowrap">
          {item}
        </a>
      ))}
    </nav>

    {/* Logo Central (Esconde quando a busca abre para dar espaço) */}
    <div className={`absolute left-1/2 -translate-x-1/2 bg-white px-6 py-2 rounded-full border border-gray-100 shadow-sm transition-opacity ${isSearchOpen ? 'opacity-0' : 'opacity-100'}`}>
       {company.logo ? (
          <img src={company.logo} alt={company.name} className="h-6 w-auto" />
        ) : (
          <span className="font-bold text-lg text-[#0E7D83]">🌿 Homecare</span>
        )}
    </div>

    {/* Ações Direita & Lógica de Busca */}
    <div className="flex items-center gap-2 z-10">
      
      {/* AREA DE BUSCA DINÂMICA */}
      <div className="flex items-center">
        {!isSearchOpen ? (
          <button 
            onClick={() => setIsSearchOpen(true)} 
            className="w-10 h-10 flex items-center justify-center bg-[#E5E65D] rounded-full text-black hover:scale-105 transition-transform"
          >
            <Search size={18} />
          </button>
        ) : (
          <div className="flex items-center gap-3 bg-white border border-gray-200 px-4 py-2 rounded-full animate-in fade-in zoom-in-95 duration-300 w-[250px] lg:w-[400px] shadow-sm">
            <Search size={16} className="text-[#0E7D83]" />
            <input 
              autoFocus
              type="text"
              placeholder="Search services..."
              className="bg-transparent border-none outline-none text-sm w-full placeholder:text-gray-400 text-gray-800"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button onClick={() => setIsSearchOpen(false)} className="text-gray-400 hover:text-red-500 transition-colors">
              <X size={18} />
            </button>
          </div>
        )}
      </div>
      
      {/* Botões de Navegação Direita (Esconde se a busca estiver aberta em telas menores) */}
      {!isSearchOpen && (
        <>
          <div className="hidden lg:flex items-center gap-2">
            {['Solutions', 'Projects'].map((item) => (
              <a key={item} href={`#${item.toLowerCase()}`} className="px-5 py-2 bg-white rounded-full text-[13px] font-medium text-gray-700 border border-gray-100">
                {item}
              </a>
            ))}
          </div>

          <button className="hidden sm:block px-6 py-2 bg-[#E5E65D] rounded-full text-[13px] font-bold text-black hover:brightness-95 transition-all">
            Get Started
          </button>
        </>
      )}
      
      {/* Botão do Carrinho */}
      <button 
        onClick={() => setIsCartOpen(true)} 
        className={`relative p-2 text-[#0E7D83] transition-opacity ${isSearchOpen ? 'hidden lg:block' : 'block'}`}
      >
        <Briefcase size={22} />
        {cart.length > 0 && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center animate-bounce">
            {cart.length}
          </span>
        )}
      </button>
    </div>
  </div>
</header>


    {/* 2. HERO SECTION (Mantido conforme o layout Stas) */}
<section className="bg-[#f8f7f2] px-6 pb-10">
  <div className="max-w-[1440px] mx-auto bg-[#0E7D83] rounded-[60px] relative overflow-hidden min-h-[700px] flex items-center px-16">
    
    {/* Padrão de Grid ao Fundo */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px'}} />

    <div className="grid grid-cols-12 w-full items-center relative z-10">
      
      {/* Conteúdo Texto (Esquerda) */}
      <div className="col-span-12 lg:col-span-6 space-y-8">
        <div className="flex items-center gap-3">
          <span className="text-white/60 text-sm">Meet With</span>
          <div className="w-12 h-[1px] bg-white/40" />
        </div>

        <h1 className="text-6xl md:text-8xl font-bold text-white leading-tight">
          {portalContent?.hero?.headline || "We provide top-notch residential and commercial cleaning services tailored to your needs. Trusted, trained, and always on time."}
       
        </h1>

        <p className="text-white/60 max-w-md text-lg leading-relaxed">
          {portalContent?.hero?.subheadline || "We provide top-notch residential and commercial cleaning services tailored to your needs. Trusted, trained, and always on time."}
        </p>

        <div className="flex items-center gap-4">
          <button className="px-8 py-4 bg-[#E5E65D] text-black font-bold rounded-full hover:scale-105 transition-transform shadow-lg">
            See Our Services
          </button>
          <button className="px-8 py-4 bg-white/10 text-white font-medium rounded-full border border-white/20 hover:bg-white/20 transition-all">
            Learn More
          </button>
        </div>

        {/* Footer do Hero (Logos de Marcas) */}
        <div className="pt-12 flex items-center gap-8 opacity-50 grayscale invert">
           <span className="text-white text-xs font-medium shrink-0">Trusted by the world's <br/> biggest brands</span>
           <div className="flex gap-6 items-center">
              {/* Substituir por logos reais */}
              <span className="text-white font-bold italic">afterpay</span>
              <span className="text-white font-bold">Basecamp</span>
              <span className="text-white font-bold">maze</span>
           </div>
        </div>
      </div>

      {/* Imagem Principal (Direita - Recortada) */}
      <div className="col-span-12 lg:col-span-6 relative flex justify-end">
        <img 
          src={getImageUrl(portalContent?.hero?.backgroundImage) || "URL_DA_PROFISSIONAL_LIMPEZA"} 
          alt="Cleaning Professional" 
          className="h-[750px] w-auto object-contain translate-y-10" 
        />
        
        {/* Badge Flutuante (5.1k) */}
        <div className="absolute bottom-10 right-0 bg-white p-4 rounded-3xl shadow-xl flex items-center gap-4">
          <div>
            <div className="text-2xl font-black text-[#0E7D83]">5.1K</div>
            <div className="text-[10px] text-gray-500 uppercase font-bold">All Over World</div>
          </div>
          <div className="flex -space-x-3">
             {[1,2,3].map(i => (
               <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-200 overflow-hidden">
                 <img src={`https://i.pravatar.cc/100?u=${i}`} alt="user" />
               </div>
             ))}
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

    {/* OVERLAY DE PESQUISA (Opcional - Sugestões Rápidas de Advocacia) */}
    {isSearchOpen && (
      <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[55] pointer-events-none transition-opacity" />
    )}

{/* === SEÇÕES DINÂMICAS DO PORTAL CONTENT === */}

{/* About Section – Estilo Premium Trust */}
{portalContent?.about?.enabled && (
  <section id="about" className="py-24 bg-[#f8f7f2] overflow-hidden">
    <div className="max-w-7xl mx-auto px-6">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        
        {/* Lado Esquerdo: Conteúdo */}
        <div className="space-y-8 order-2 lg:order-1">
          <div className="space-y-6">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-[#0E7D83]">
              {/* Lógica para destacar a primeira ou segunda palavra com fundo amarelo */}
              {portalContent.about.title ? (
                <>
                  {portalContent.about.title.split(' ')[0]}{' '}
                  <span className="relative inline-block">
                    <span className="relative z-10 bg-[#E5E65D] px-2 rounded-lg">
                      {portalContent.about.title.split(' ')[1]}
                    </span>
                  </span>
                  {' '}{portalContent.about.title.split(' ').slice(2).join(' ')}
                </>
              ) : (
                <>
                  Cleaning <span className="bg-[#E5E65D] px-2 rounded-lg">With Care</span>, Backed By Trust
                </>
              )}
            </h2>
            
            <div 
              className="text-lg leading-relaxed text-gray-600 max-w-xl" 
              dangerouslySetInnerHTML={{ __html: portalContent.about.body || 'We understand your home is personal. That’s why we bring respect, consistency, and genuine care.' }} 
            />
          </div>

          {/* Lista de Benefícios (conforme a imagem image_2a6c1d.png) */}
          <div className="grid grid-cols-2 gap-4">
            {[
              'Respect for Team', 
              'Consistent Quality', 
              'Unique Needs', 
              'Secure Key Handling'
            ].map((item) => (
              <div key={item} className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-[#E5E65D] flex items-center justify-center shrink-0">
                  <Check size={12} className="text-[#0E7D83] stroke-[4px]" />
                </div>
                <span className="text-sm font-semibold text-[#0E7D83]">{item}</span>
              </div>
            ))}
          </div>

          <button className="px-10 py-4 bg-[#0E7D83] text-white font-bold rounded-full hover:bg-[#082d22] transition-all shadow-lg">
            Learn More
          </button>
        </div>

        {/* Lado Direito: Imagem com Moldura Orgânica (Estilo Folha) */}
        <div className="relative order-1 lg:order-2 flex justify-center">
          <div className="relative w-full max-w-[500px] aspect-square">
            
            {/* Moldura de Folhas Decorativas */}
            <div className="absolute inset-0 z-0 animate-pulse-slow">
              <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className="w-full h-full fill-[#94d600] opacity-20">
                <path d="M40,-62.7C53.3,-54.1,66.5,-45.4,74.2,-33.1C81.9,-20.8,84.1,-4.9,80.1,9.8C76.1,24.5,65.9,38,54,48.5C42.1,59,28.5,66.5,13.8,70.1C-0.9,73.7,-16.7,73.4,-31.1,67.8C-45.5,62.2,-58.5,51.3,-67.2,38.1C-75.9,24.9,-80.3,9.4,-77.8,-4.9C-75.3,-19.2,-65.9,-32.3,-54.7,-41.8C-43.5,-51.3,-30.5,-57.2,-17.7,-65.5C-4.9,-73.8,7.8,-84.5,22.2,-82.1C36.6,-79.7,52.6,-64.1,40,-62.7Z" transform="translate(100 100)" />
              </svg>
            </div>

            {/* Imagem Circular Principal */}
            <div className="relative z-10 w-full h-full rounded-full border-[12px] border-white shadow-2xl overflow-hidden flex items-center justify-center">
              {portalContent.about.image ? (
                <img 
                  src={getImageUrl(portalContent.about.image)} 
                  alt="About Us" 
                  className="w-full h-full object-cover" 
                />
              ) : (
                <img 
                  src="https://images.unsplash.com/photo-1581578731548-c64695cc6954?auto=format&fit=crop&q=80" 
                  alt="Placeholder"
                  className="w-full h-full object-cover"
                />
              )}
            </div>

            {/* Ícones de Folha (Pode usar SVGs ou imagens pequenas) */}
            <div className="absolute -top-4 -left-4 w-20 h-20 bg-[#94d600] rounded-full flex items-center justify-center shadow-lg border-4 border-white rotate-[-15deg] z-20">
               <Leaf className="text-white" size={32} />
            </div>
            <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-[#94d600] rounded-full flex items-center justify-center shadow-lg border-4 border-white rotate-[165deg] z-20">
               <Leaf className="text-white" size={24} />
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>
)}







 {/* agora três secções sequenciais com colapso */}
  <div className="">
{/* Section: Practice Areas & Services — Editorial Aesthetic */}
{filteredServices.length > 0 && (
  <section id="services" className="py-24 bg-[#f8f7f2]">
    <div className="max-w-7xl mx-auto px-6">
      
      {/* Cabeçalho no estilo da imagem */}
      <div className="grid grid-cols-1 md:grid-cols-3 items-center gap-8 mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-[#0E7D83] leading-tight">
          How Our {company.name || "Cleaning"} <br /> Service Works
        </h2>
        <p className="text-gray-500 text-sm md:border-l border-gray-200 md:pl-8">
          Getting your space professionally cleaned is easier than ever — just follow these simple steps or explore our specialized areas.
        </p>
        <div className="flex justify-start md:justify-end">
          <button className="flex items-center gap-2 px-6 py-3 border border-[#0E7D83] rounded-full text-[#0E7D83] font-bold hover:bg-[#0E7D83] hover:text-white transition-all duration-300">
            Read More <Plus size={16} />
          </button>
        </div>
      </div>

      {/* Grid Assimétrico (Bento Grid) inspirado na image_2a60db.jpg */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {filteredServices.slice(0, visibleServices).map((item, index) => {
          // Lógica para alternar o tamanho das colunas no grid
          const gridSpans = [
            "md:col-span-4 h-[350px]", // Item 1 (Pequeno)
            "md:col-span-5 h-[350px]", // Item 2 (Médio)
            "md:col-span-3 h-[350px]", // Item 3 (Estreito)
            "md:col-span-7 h-[450px]", // Item 4 (Grande)
            "md:col-span-5 h-[450px]", // Item 5 (Médio)
          ];
          const currentSpan = gridSpans[index % gridSpans.length];

          return (
            <div
              key={item._id}
              onClick={() => openItem(item, 'services')}
              className={`group relative rounded-[2.5rem] overflow-hidden cursor-pointer bg-white transition-all duration-500 shadow-sm hover:shadow-xl ${currentSpan}`}
            >
              {/* Imagem de Fundo */}
              <div className="absolute inset-0 z-0">
                {item.images?.length > 0 ? (
                  <img 
                    src={getImageUrl(item.images[0])} 
                    alt={item.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full bg-[#f1ebe5]" />
                )}
              </div>

              {/* Botão de Ação Circular (Ícone no canto) */}
              <div className="absolute top-6 right-6 z-20">
                <div className="w-10 h-10 bg-[#E5E65D] rounded-full flex items-center justify-center text-[#0E7D83] shadow-lg group-hover:rotate-45 transition-transform duration-500">
                  <ArrowUpRight size={20} />
                </div>
              </div>

              {/* Legenda Translúcida (Estilo da imagem de referência) */}
              <div className="absolute bottom-6 left-6 right-6 z-20">
                <div className="bg-white/60 backdrop-blur-md p-6 rounded-3xl border border-white/40">
                  <h3 className="text-lg font-bold text-[#0E7D83] mb-1">
                    {item.name}
                  </h3>
                  <p className="text-[#0E7D83]/80 text-[11px] line-clamp-2 leading-relaxed">
                    {item.description || "Top-notch cleaning services tailored to your specific household or commercial needs."}
                  </p>
                </div>
              </div>
              
              {/* Badge "Being Popular" (Opcional - aparece no card de baixo da imagem) */}
              {index === 3 && (
                <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-30">
                  <span className="bg-[#0E7D83] text-white text-[10px] px-4 py-2 rounded-full font-bold whitespace-nowrap shadow-xl">
                    Being Popular
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Botão Carregar Mais adaptado */}
      {visibleServices < filteredServices.length && (
        <div className="mt-16 flex justify-center">
          <button 
            onClick={() => setVisibleServices(prev => prev + 3)}
            className="group flex items-center gap-3 px-8 py-4 bg-[#0E7D83] text-white rounded-full font-bold hover:scale-105 transition-all shadow-lg"
          >
            Expand Services
            <Plus size={18} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>
      )}
    </div>
  </section>
)}
{/* Missão, Visão e Valores – Estilo Dark Cinematic */}
{portalContent?.missionVision?.enabled && (
  <section className="py-24 bg-[#f8f7f2] px-6">
    {/* Container Principal Estilo Card Verde */}
    <div className="max-w-7xl mx-auto bg-[#0E7D83] rounded-[60px] pt-20 pb-28 px-10 relative overflow-hidden text-center">
      
      {/* Elementos Decorativos (Trevos/Folhas conforme image_2a58da.png) */}
      <div className="absolute top-10 left-10 opacity-20 rotate-12">
        <Leaf size={60} className="text-[#94d600]" />
      </div>
      <div className="absolute top-10 right-20 opacity-20 -rotate-12">
        <Leaf size={40} className="text-[#94d600]" />
      </div>

      {/* Título Centralizado */}
      <div className="relative z-10 mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">
          What Makes Us the <br />
          <span className="text-[#E5E65D]">Right Choice</span>
        </h2>
      </div>

      {/* Grid de Cards com Inclinação (Skew) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10">
        
        {/* Card Missão */}
        <div className="bg-[#f0f9f0] p-8 rounded-[2rem] text-left transition-transform hover:scale-105 duration-300 transform -rotate-1 lg:-rotate-2 origin-bottom-right shadow-xl">
          <div className="w-12 h-12 bg-[#E5E65D] rounded-xl flex items-center justify-center mb-6 shadow-sm">
            <Target size={24} className="text-[#0E7D83]" />
          </div>
          <h3 className="text-xl font-bold text-[#0E7D83] mb-4">
            {portalContent?.missionVision?.mission?.title || "Mission"}
          </h3>
          <p className="text-[#0E7D83]/70 text-sm leading-relaxed mb-6">
            {portalContent?.missionVision?.mission?.content || "To provide strategic intelligence that empowers our clients to navigate complex environments with absolute confidence."}
          </p>
          <button className="text-[10px] font-bold uppercase tracking-widest text-[#0E7D83] border-b-2 border-[#E5E65D]">
            Learn More
          </button>
        </div>

        {/* Card Visão */}
        <div className="bg-[#f0f9f0] p-8 rounded-[2rem] text-left transition-transform hover:scale-105 duration-300 transform rotate-1 lg:rotate-2 origin-bottom-left shadow-xl">
          <div className="w-12 h-12 bg-[#E5E65D] rounded-xl flex items-center justify-center mb-6 shadow-sm">
            <Eye size={24} className="text-[#0E7D83]" />
          </div>
          <h3 className="text-xl font-bold text-[#0E7D83] mb-4">
            {portalContent?.missionVision?.vision?.title || "Vision"}
          </h3>
          <p className="text-[#0E7D83]/70 text-sm leading-relaxed mb-6">
            {portalContent?.missionVision?.vision?.content || "To be recognized globally as the standard of excellence, bridging the gap between innovation and traditional values."}
          </p>
          <button className="text-[10px] font-bold uppercase tracking-widest text-[#0E7D83] border-b-2 border-[#E5E65D]">
            Learn More
          </button>
        </div>

        {/* Card Valores (Estilo Diferenciado) */}
        <div className="bg-[#f0f9f0] p-8 rounded-[2rem] text-left transition-transform hover:scale-105 duration-300 shadow-xl md:col-span-2 lg:col-span-1">
          <div className="w-12 h-12 bg-[#E5E65D] rounded-xl flex items-center justify-center mb-6 shadow-sm">
            <ShieldCheck size={24} className="text-[#0E7D83]" />
          </div>
          <h3 className="text-xl font-bold text-[#0E7D83] mb-4">
            {portalContent?.missionVision?.values?.title || "Core Values"}
          </h3>
          <ul className="grid grid-cols-2 gap-y-3">
            {(portalContent?.missionVision?.values?.items?.length > 0 
              ? portalContent.missionVision.values.items 
              : ["Integrity", "Innovation", "Precision", "Success"]
            ).map((v, i) => (
              <li key={i} className="flex items-center gap-2 text-xs font-bold text-[#0E7D83]/80">
                <div className="w-1.5 h-1.5 rounded-full bg-[#94d600]" />
                {v}
              </li>
            ))}
          </ul>
        </div>

      </div>

      {/* Botão Inferior "Get Started" Saindo do Card */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 z-20">
        <button className="bg-[#E5E65D] text-[#0E7D83] px-12 py-5 rounded-full font-black uppercase tracking-widest text-sm shadow-[0_10px_30px_rgba(0,0,0,0.2)] hover:scale-110 transition-transform">
          Get Started
        </button>
      </div>
    </div>
  </section>
)}
{/* — Seção de Produtos/Soluções Estilo Boutique Legal — */}
{filteredProducts.length > 0 && (
  <section className="py-24 bg-[#f8f7f2] text-[#0E7D83] relative overflow-hidden">
    {/* Trevo decorativo sutil no canto superior esquerdo */}
    <div className="absolute top-10 left-10 opacity-10 rotate-12">
      <Leaf size={80} className="text-[#94d600]" />
    </div>

    <div className="max-w-7xl mx-auto px-6 relative z-10">
      
      {/* Header Estilo image_2a5217.png */}
      <div className="mb-16 grid grid-cols-1 lg:grid-cols-2 gap-8 items-end">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-[1px] bg-[#0E7D83]" />
            <span className="text-xs font-bold uppercase tracking-widest opacity-60">
              Curated Resources
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight leading-tight">
            Expert Solutions for <br /> Premium Operations
          </h2>
        </div>
        <div className="flex flex-col lg:items-end gap-6">
          <p className="text-gray-500 text-sm md:text-base max-w-md lg:text-right">
            Explore our full range of professional toolkits and assets designed to keep every aspect of your business comfortable and inviting.
          </p>
          {/* Setas de Navegação Estilizadas */}
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-white hover:text-[#0E7D83] transition-all cursor-pointer">
              <ChevronLeft size={20} />
            </div>
            <div className="w-10 h-10 rounded-full bg-[#0E7D83] flex items-center justify-center text-white shadow-lg cursor-pointer">
              <ChevronRight size={20} />
            </div>
          </div>
        </div>
      </div>

      {/* Grid de Produtos adaptado ao estilo de Carrossel Vertical */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {(showAllProducts ? filteredProducts : filteredProducts.slice(0, 4)).map((item, index) => {
          const firstImage = Array.isArray(item.images) && item.images.length > 0 ? item.images[0] : item.image;
          const imageUrl = getImageUrl(firstImage || '');
          
          // O primeiro card tem o estilo invertido (verde escuro) conforme a imagem image_2a5217.png
          const isFirst = index === 0;

          return (
            <div
              key={item._id}
              onClick={() => openItem(item, 'products')}
              className={`group relative flex flex-col transition-all duration-500 cursor-pointer rounded-[2.5rem] overflow-hidden h-[520px] shadow-sm hover:shadow-xl ${
                isFirst ? 'bg-[#0E7D83] text-white' : 'bg-white text-[#0E7D83]'
              }`}
            >
              {/* Topo do Card: Texto e Badge */}
              <div className="p-8 pb-4">
                <div className="flex justify-between items-start mb-6">
                  <div className={`px-4 py-1.5 rounded-full text-[10px] font-bold border ${
                    isFirst ? 'border-white/20 text-white' : 'border-gray-100 text-gray-500'
                  }`}>
                    {item.category || 'Premium'}
                  </div>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    isFirst ? 'bg-[#E5E65D] text-[#0E7D83]' : 'bg-[#0E7D83] text-white'
                  }`}>
                    <ArrowUpRight size={16} />
                  </div>
                </div>

                <h3 className="text-2xl font-bold mb-4 leading-tight">
                  {item.name}
                </h3>
                <p className={`text-xs leading-relaxed line-clamp-3 mb-4 ${
                  isFirst ? 'text-white/70' : 'text-gray-500'
                }`}>
                  {item.description || "Sophisticated infrastructure designed for elite business operations."}
                </p>
                
                {/* Preço sutil */}
                <span className="text-sm font-black opacity-80">
                  {getItemPrice(item).toLocaleString()} {currency}
                </span>
              </div>

              {/* Base do Card: Imagem com cantos específicos conforme a referência */}
              <div className="mt-auto px-4 pb-4">
                <div className="h-60 w-full overflow-hidden rounded-[2rem]">
                  {imageUrl ? (
                    <img 
                      src={imageUrl} 
                      alt={item.name} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                    />
                  ) : (
                    <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                       <Package className="text-gray-300" size={32} />
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Botão Join Our Team/Explore no rodapé, conforme image_2a5217.png */}
      <div className="mt-20 flex justify-center">
        <button 
          onClick={() => setShowAllProducts(prev => !prev)}
          className="group flex items-center gap-3 px-10 py-4 bg-[#0E7D83] text-white text-xs font-bold uppercase tracking-widest rounded-full shadow-xl hover:bg-[#082d22] transition-all"
        >
          {showAllProducts ? 'Show Less' : 'Join Our Program'}
          <div className="w-6 h-6 rounded-full bg-[#E5E65D] flex items-center justify-center text-[#0E7D83]">
            <ChevronRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
          </div>
        </button>
      </div>
    </div>
  </section>
)}



{/* ── Seção: Legal Bundles (Estilo Premium Integration) ── */}
{filteredBundles.some(b => b.type === 'Combo') && (
  <section className="py-24 bg-[#f8f7f2] relative overflow-hidden">
    {/* Decoração de fundo sutil */}
    <div className="absolute -bottom-20 -left-20 opacity-5">
      <Leaf size={300} className="text-[#0E7D83]" />
    </div>

    <div className="max-w-7xl mx-auto px-6 relative z-10">
      
      {/* Cabeçalho no estilo editorial da marca */}
      <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="max-w-xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-[1px] bg-[#0E7D83]" />
            <span className="text-xs font-bold uppercase tracking-[0.3em] text-[#0E7D83] opacity-60">
              Strategic Alliances
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#0E7D83] tracking-tight leading-tight">
            Comprehensive <span className="text-[#94d600]">Service Bundles</span>
          </h2>
        </div>
        <p className="text-gray-500 text-sm max-w-xs md:text-right">
          Integrated solutions designed to provide full protection and scalability for your business operations.
        </p>
      </div>

      {/* Container de Scroll Horizontal com Snap */}
      <div className="flex gap-8 overflow-x-auto pb-12 pt-4 scrollbar-hide snap-x">
        {filteredBundles
          .filter(item => item.type === 'Combo')
          .map((item, index) => {
            const image = getImageUrl(item.image || '');
            
            return (
              <div
                key={item._id}
                onClick={() => openItem(item, 'bundles')}
                className="group relative min-w-[320px] md:min-w-[850px] snap-center transition-all duration-500 cursor-pointer"
              >
                {/* Card Principal Estilo Bento/Gallery */}
                <div className="bg-white rounded-[3.5rem] p-4 md:p-6 flex flex-col md:flex-row gap-8 h-full border border-gray-100 shadow-sm hover:shadow-2xl transition-all">
                  
                  {/* Container da Imagem (Estilo image_2a5217.png) */}
                  <div className="w-full md:w-[350px] h-[300px] md:h-[400px] rounded-[2.8rem] overflow-hidden relative shrink-0">
                    <img 
                      src={image} 
                      alt={item.name} 
                      className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
                    />
                    {/* Badge de "Combo" flutuante na imagem */}
                    <div className="absolute top-6 left-6 bg-[#E5E65D] text-[#0E7D83] text-[10px] font-black px-4 py-2 rounded-full uppercase tracking-tighter shadow-lg">
                      Best Value Pack
                    </div>
                  </div>

                  {/* Conteúdo Editorial (Estilo image_2a60db.jpg) */}
                  <div className="flex-1 flex flex-col justify-between py-4 pr-4">
                    <div>
                      <div className="flex justify-between items-start mb-6">
                        <span className="text-[11px] font-black text-[#94d600] uppercase tracking-widest">
                          Bundle Solution {index + 1 < 10 ? `0${index + 1}` : index + 1}
                        </span>
                        <div className="w-12 h-12 rounded-full bg-[#f8f7f2] flex items-center justify-center text-[#0E7D83] group-hover:bg-[#E5E65D] transition-colors duration-500">
                          <ArrowUpRight size={20} />
                        </div>
                      </div>
                      
                      <h3 className="text-3xl md:text-4xl font-bold text-[#0E7D83] mb-6 tracking-tight leading-none">
                        {item.name}
                      </h3>
                      
                      <p className="text-gray-500 text-sm md:text-base leading-relaxed mb-8 line-clamp-3">
                        {item.description || "A cohesive selection of professional frameworks designed to scale your business with maximum efficiency."}
                      </p>
                    </div>
                    
                    {/* Rodapé do Card com Preço e Botão */}
                    <div className="flex items-end justify-between border-t border-gray-50 pt-8">
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-gray-300 uppercase tracking-widest block">Retainer Investment</span>
                        <div className="text-3xl font-black text-[#0E7D83]">
                          {getItemPrice(item).toLocaleString()} <span className="text-xs opacity-40 font-medium">{currency}</span>
                        </div>
                      </div>
                      
                      <button className="bg-[#0E7D83] text-white px-8 py-4 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-3 hover:bg-[#94d600] hover:text-[#0E7D83] transition-all">
                        Get Bundle <Layers size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
      </div>

      {/* Barra de Progresso Customizada (Estilo image_2a6c1d.png) */}
      <div className="flex flex-col items-center mt-12 gap-4">
        <div className="w-48 h-[3px] bg-gray-200 rounded-full overflow-hidden">
          <div className="bg-[#0E7D83] h-full w-1/3 rounded-full" />
        </div>
        <span className="text-[10px] font-black text-[#0E7D83] uppercase tracking-[0.4em]">
          Scroll to explore
        </span>
      </div>
    </div>
  </section>
)}

{/* ── Seção: Legal Subscriptions (Estilo Boutique Law Tech) ── */}
{filteredBundles.some(b => b.type === 'Subscription') && (
  <section className="py-24 bg-white relative overflow-hidden">
    <div className="max-w-7xl mx-auto px-10 relative z-10">
      
      {/* Cabeçalho centralizado conforme image_206812.png */}
      <div className="flex flex-col items-center text-center mb-16">
        <span className="bg-[#E5E65D] text-[#0E7D83] text-[10px] font-black uppercase tracking-widest px-4 py-1 rounded-full mb-4">
          Plans
        </span>
        <h2 className="text-4xl md:text-5xl font-bold text-[#0E7D83] mb-4">
          Pricing Plans
        </h2>
        <p className="text-gray-400 text-sm mb-10">
          Check our easy and simple plans
        </p>
        
        {/* Toggle UI - Estilo image_206812.png */}
        <div className="flex items-center gap-4">
          <span className="text-xs font-bold text-gray-400">Yearly</span>
          <div className="w-14 h-7 bg-[#f8f7f2] rounded-full p-1 flex items-center relative cursor-pointer border border-gray-100">
            <div className="w-5 h-5 bg-[#E5E65D] rounded-full shadow-sm" />
          </div>
          <span className="text-xs font-bold text-gray-400">Monthly</span>
        </div>
      </div>

      {/* Grid de Planos com o corte diagonal (Clip-path) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
        {filteredBundles.filter(item => item.type === 'Subscription').map((plan, index) => {
          // Alternância de cores conforme a imagem de referência
          const isDark = index % 2 === 0;

          return (
            <div 
              key={plan._id} 
              className={`relative p-12 flex flex-col group transition-all duration-500
                ${isDark ? 'bg-[#0E7D83] text-white' : 'bg-[#f8f7f2] text-[#0E7D83]'}
              `}
              style={{
                // Simulação do corte diagonal da image_206812.png
                clipPath: 'polygon(0 0, 65% 0, 100% 15%, 100% 100%, 0 100%)',
                borderRadius: '2rem'
              }}
            >
              <div className="mb-8">
                <h3 className="text-3xl font-bold mb-2">
                  {plan.name}
                </h3>
                <p className={`text-xs opacity-70 mb-6`}>
                  {plan.description || "Our individual law-tech solutions."}
                </p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold">
                    ${getItemPrice(plan).toLocaleString()}
                  </span>
                  <span className="text-sm opacity-60">/mo</span>
                </div>
              </div>
              
              <div className="flex-1">
                <p className="text-xs font-bold uppercase tracking-widest mb-6 opacity-80">Includes</p>
                <ul className="space-y-4 mb-10">
                  {plan.includedLimits?.map((limit: any, i: number) => (
                    <li key={i} className="flex items-center gap-3 text-sm">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${isDark ? 'bg-white/10' : 'bg-[#0E7D83]/10'}`}>
                        <Check size={12} className={isDark ? 'text-[#E5E65D]' : 'text-[#0E7D83]'} strokeWidth={3} />
                      </div>
                      <span className="opacity-90">{limit.description}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Botão Estilo image_206812.png */}
              <button 
                onClick={() => { addToCart(plan, 'bundles'); }} 
                className={`w-full py-4 rounded-full font-bold text-sm transition-all active:scale-95
                  ${isDark 
                    ? 'bg-[#E5E65D] text-[#0E7D83] hover:bg-white' 
                    : 'bg-[#0E7D83] text-white hover:bg-[#0E7D83]/90'}`}
              >
                Get This Plan
              </button>
            </div>
          );
        })}
      </div>
    </div>
  </section>
)}
  </div>
  {/* Clientes / Parceiros */}
{portalContent?.clients?.enabled && portalContent.clients.items?.length > 0 && (
  <section className="py-24 bg-[#f8f7f2] relative overflow-hidden">
    {/* Elemento decorativo sutil para continuidade visual */}
    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-[1px] bg-gradient-to-r from-transparent via-[#0E7D83]/10 to-transparent" />

    <div className="max-w-7xl mx-auto px-6 relative z-10">
      
      {/* Label de confiança no estilo da marca */}
      <div className="flex flex-col items-center mb-16">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-8 h-[1px] bg-[#0E7D83] opacity-20" />
          <span className="text-[10px] font-black uppercase tracking-[0.5em] text-[#0E7D83] opacity-60">
            Trusted by Industry Leaders
          </span>
          <div className="w-8 h-[1px] bg-[#0E7D83] opacity-20" />
        </div>
      </div>

      {/* Grid de Logotipos com Glassmorphism sutil */}
      <div className="flex flex-wrap justify-center items-center gap-x-16 gap-y-12">
        {portalContent.clients.items.map((client: any, i: number) => (
          <div 
            key={i} 
            className="group relative flex items-center justify-center transition-all duration-500"
          >
            {/* Efeito de brilho ao passar o mouse */}
            <div className="absolute inset-0 bg-white blur-2xl rounded-full opacity-0 group-hover:opacity-40 transition-opacity duration-700" />
            
            <img 
              src={getImageUrl(client.logo)} 
              alt={client.name} 
              className="h-8 md:h-10 w-auto object-contain grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500 relative z-10" 
            />
          </div>
        ))}
      </div>

      {/* Frase de rodapé sutil para fechar a seção */}
      <div className="mt-16 flex justify-center">
        <div className="h-1.5 w-1.5 rounded-full bg-[#E5E65D]" />
      </div>
    </div>
  </section>
)}

{/* — Testemunhos: Estilo Editorial & Prestige — */}
{portalContent?.testimonials?.enabled && portalContent.testimonials.items?.length > 0 && (
  <section id="testimonials" className="py-24 bg-white relative overflow-hidden">
    
    {/* Elemento Decorativo Sutil de Fundo */}
    <div className="absolute -top-24 -right-24 opacity-[0.03] rotate-12">
      <Quote size={500} className="text-[#0E7D83]" />
    </div>

    <div className="max-w-7xl mx-auto px-6 relative z-10">
      
      {/* Header Alinhado ao Estilo de Planos da image_206812.png */}
      <div className="flex flex-col items-center text-center mb-20">
        <span className="bg-[#E5E65D] text-[#0E7D83] text-[10px] font-black uppercase tracking-[0.4em] px-5 py-1.5 rounded-full mb-6">
          Testimonials
        </span>
        <h2 className="text-4xl md:text-5xl font-bold text-[#0E7D83] tracking-tight leading-none">
          Trusted by <span className="text-[#94d600]">Industry Leaders</span>
        </h2>
        <div className="mt-6 w-12 h-1 bg-[#0E7D83] rounded-full opacity-10" />
      </div>

      {/* Grid de Testemunhos Estilo Bento */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {portalContent.testimonials.items.map((t, i) => {
          // Alternância de destaque baseada na lógica da image_206812.png
          const isFeatured = i === 1; // O card do meio ganha destaque

          return (
            <div 
              key={i} 
              className={`p-10 flex flex-col justify-between transition-all duration-500 hover:shadow-xl
                ${isFeatured 
                  ? 'bg-[#0E7D83] text-white' 
                  : 'bg-[#f8f7f2] text-[#0E7D83]'
                }`}
              style={{
                // Aplicação do corte diagonal característico da marca
                clipPath: 'polygon(0 0, 85% 0, 100% 10%, 100% 100%, 0 100%)',
                borderRadius: '2.5rem'
              }}
            >
              <div>
                {/* Rating com Estrela Amarela da image_206812.png */}
                <div className="flex gap-1 mb-8">
                  {Array.from({ length: t.rating || 5 }).map((_, k) => (
                    <Star key={k} size={14} className="fill-[#E5E65D] text-[#E5E65D]" />
                  ))}
                </div>

                <blockquote className="relative">
                  <p className={`text-lg font-bold leading-snug tracking-tight mb-10 ${isFeatured ? 'text-white' : 'text-[#0E7D83]'}`}>
                    "{t.text}"
                  </p>
                </blockquote>
              </div>

              {/* Assinatura com Avatar Grayscale */}
              <div className="flex items-center gap-4 pt-8 border-t border-current opacity-20">
                <div className="w-12 h-12 rounded-full bg-white/10 overflow-hidden shrink-0 grayscale group-hover:grayscale-0 transition-all border border-current opacity-40">
                  {t.avatar ? (
                    <img src={t.avatar} alt={t.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className={`w-full h-full flex items-center justify-center font-bold text-xs uppercase ${isFeatured ? 'bg-white text-[#0E7D83]' : 'bg-[#0E7D83] text-white'}`}>
                      {t.name?.substring(0, 2)}
                    </div>
                  )}
                </div>
                <div>
                  <p className="font-black text-sm uppercase tracking-tighter leading-none mb-1">{t.name}</p>
                  <p className={`text-[9px] font-bold uppercase tracking-widest opacity-60`}>
                    {t.role} <span className="mx-1">/</span> {t.company}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer da Seção Estilo Rodapé de Cards */}
      <div className="mt-20 flex flex-col items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#E5E65D]" />
          <span className="text-[10px] font-black uppercase tracking-[0.5em] text-[#0E7D83] opacity-30">
            Verified Success Stories
          </span>
          <div className="w-2 h-2 rounded-full bg-[#E5E65D]" />
        </div>
      </div>
    </div>
  </section>
)}



{/* Item Details Modal - Luxury Boutique Style */}
{/* Item Details Modal - Immersive "New Page" Style */}
{selectedItem && (
  <div className="fixed inset-0 z-[100] flex justify-end">
    {/* Overlay com Blur Ultra-Deep */}
    <div 
      className="absolute inset-0 bg-[#0E7D83]/40 backdrop-blur-xl transition-opacity duration-700" 
      onClick={() => { setSelectedItem(null); setCurrentImgIndex(0); }} 
    />

    {/* Conteúdo do Modal - Desliza da direita ou expande */}
    <div className="relative w-full max-w-6xl bg-[#f8f7f2] shadow-[-20px_0_80px_rgba(0,0,0,0.2)] h-full overflow-y-auto animate-in slide-in-from-right duration-500">
      
      {/* Botão de Fechar Estilo "Floating Action" */}
      <button 
        onClick={() => { setSelectedItem(null); setCurrentImgIndex(0); }} 
        className="fixed top-8 right-8 z-[110] w-14 h-14 flex items-center justify-center rounded-full bg-[#E5E65D] text-[#0E7D83] hover:bg-[#0E7D83] hover:text-white transition-all duration-500 shadow-xl"
      >
        <X size={24} strokeWidth={3} />
      </button>

      <div className="flex flex-col lg:flex-row min-h-screen">
        
        {/* LADO ESQUERDO: Visual Imersivo (60% da tela) */}
        <div className="relative w-full lg:w-[60%] h-[50vh] lg:h-screen bg-[#0E7D83] p-8 lg:p-12 flex flex-col">
          <div className="flex items-center gap-4 mb-12">
            <div className="w-10 h-[1px] bg-[#E5E65D]" />
            <span className="text-[10px] font-black uppercase tracking-[0.5em] text-[#E5E65D]">
              Product Deep Dive
            </span>
          </div>

          <div className="flex-1 relative group">
            {(() => {
              const itemImages = selectedItem.images && Array.isArray(selectedItem.images) && selectedItem.images.length > 0
                ? selectedItem.images 
                : selectedItem.image ? [selectedItem.image] : [];
              const imageUrl = getImageUrl(itemImages[currentImgIndex] || '');

              return (
                <div className="w-full h-full">
                  <div 
                    className="w-full h-full rounded-[3rem] overflow-hidden shadow-2xl transition-all duration-1000"
                    style={{ clipPath: 'polygon(0 0, 90% 0, 100% 10%, 100% 100%, 0 100%)' }}
                  >
                    {imageUrl ? (
                      <img src={imageUrl} className="w-full h-full object-cover" alt={selectedItem.name} />
                    ) : (
                      <div className="w-full h-full bg-[#082d22] flex items-center justify-center">
                        <Package size={80} className="text-[#0E7D83]" />
                      </div>
                    )}
                  </div>
                  
                  {/* Navegação de Imagem Estilo Galeria de Arte */}
                  {itemImages.length > 1 && (
                    <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 flex gap-4 bg-white/10 backdrop-blur-md p-4 rounded-full border border-white/10">
                      {itemImages.map((_, idx) => (
                        <button 
                          key={idx}
                          onClick={() => setCurrentImgIndex(idx)}
                          className={`h-2 rounded-full transition-all duration-500 ${idx === currentImgIndex ? 'w-12 bg-[#E5E65D]' : 'w-2 bg-white/30'}`}
                        />
                      ))}
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        </div>

        {/* LADO DIREITO: Informação Editorial (40% da tela) */}
        <div className="flex-1 p-8 lg:p-20 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-10">
              <span className="text-[10px] font-black text-[#94d600] uppercase tracking-widest px-4 py-2 bg-[#0E7D83]/5 rounded-full">
                {selectedItem.category || 'Premium Service'}
              </span>
              <div className="flex gap-1">
                {[1,2,3,4,5].map(s => <Star key={s} size={10} className="fill-[#E5E65D] text-[#E5E65D]" />)}
              </div>
            </div>

            <h3 className="text-5xl lg:text-6xl font-bold text-[#0E7D83] mb-8 tracking-tighter leading-[0.9]">
              {selectedItem.name}
            </h3>

            <p className="text-gray-500 text-lg leading-relaxed mb-12 font-medium">
              {selectedItem.description || "Sophisticated framework designed for modern operations with emphasis on efficiency and long-term scalability."}
            </p>

            {/* Lista de Features no Estilo de Checklist da image_206812.png */}
            <div className="space-y-4 mb-12">
              <h4 className="text-[#0E7D83] text-[10px] font-black uppercase tracking-[0.3em] mb-6">Core Provisions</h4>
              {(selectedItem.includedItems || selectedItem.items || []).slice(0, 5).map((it, i) => (
                <div key={i} className="flex items-center gap-4 py-4 border-b border-gray-100 group">
                  <div className="w-6 h-6 rounded-full bg-[#0E7D83] flex items-center justify-center text-[#E5E65D] group-hover:scale-110 transition-transform">
                    <Check size={12} strokeWidth={4} />
                  </div>
                  <span className="text-sm font-bold text-[#0E7D83]">{it.productId?.name || it.description || "Strategic Asset"}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Action Bar Inferior - Fixa o valor e o CTA */}
          <div className="pt-12 border-t border-gray-200">
            <div className="flex flex-col gap-8">
              <div className="flex justify-between items-end">
                <div>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-2">Service Investment</span>
                  <div className="text-5xl font-black text-[#0E7D83] tracking-tighter">
                    {getItemPrice(selectedItem).toLocaleString()} <span className="text-lg opacity-40">{currency}</span>
                  </div>
                </div>
                {selectedItem.billingCycle && (
                  <span className="text-xs font-bold text-[#94d600] uppercase mb-2">Billed {selectedItem.billingCycle}</span>
                )}
              </div>

              <button 
                onClick={() => { addToCart(selectedItem, activeCatalog); setSelectedItem(null); }}
                className="w-full py-6 bg-[#0E7D83] text-[#E5E65D] font-black text-xs uppercase tracking-[0.5em] rounded-full shadow-2xl hover:bg-[#082d22] transition-all transform active:scale-[0.98] flex items-center justify-center gap-4"
              >
                Apply for Access <ArrowRight size={18} />
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
)}

{/* CART MODAL – Luxury Legal & Advisory Edition */}
{/* CART MODAL – Luxury Immersive "Full Page" Edition */}
<div className={`fixed inset-0 z-[100] flex justify-end ${isCartOpen ? 'pointer-events-auto' : 'pointer-events-none'}`}>
  
  {/* Overlay com Blur Profundo */}
  <div
    className={`absolute inset-0 bg-[#0E7D83]/60 backdrop-blur-xl transition-opacity duration-700 ${isCartOpen ? 'opacity-100' : 'opacity-0'}`}
    onClick={() => setIsCartOpen(false)}
  />

  {/* Modal Container - Desliza da direita ocupando quase toda a tela */}
  <div
    className={`relative w-full max-w-6xl bg-[#f8f7f2] shadow-[-20px_0_80px_rgba(0,0,0,0.3)] h-full transform transition-all duration-700 ease-out flex flex-col ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}
  >
    
    {/* Close Button - Estilo Floating da Marca */}
    <button 
      onClick={() => setIsCartOpen(false)} 
      className="absolute top-8 right-8 z-[110] w-14 h-14 flex items-center justify-center rounded-full bg-[#E5E65D] text-[#0E7D83] hover:bg-[#0E7D83] hover:text-white transition-all duration-500 shadow-xl"
    >
      <X size={24} strokeWidth={3} />
    </button>

    <div className="flex flex-col lg:flex-row h-full overflow-hidden">
      
      {/* COLUNA ESQUERDA: Portfolio Selection (Scrollable) */}
      <div className="flex-[1.4] flex flex-col min-h-0 bg-white lg:rounded-r-[4rem] shadow-xl z-10">
        <div className="p-10 lg:p-16 border-b border-gray-50">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-10 h-[1px] bg-[#0E7D83]" />
            <span className="text-[10px] font-black uppercase tracking-[0.5em] text-[#0E7D83]">Service Portfolio</span>
          </div>
          <h2 className="text-5xl font-bold text-[#0E7D83] tracking-tighter uppercase leading-none">
            Selected <span className="opacity-20 italic font-serif lowercase">Assets</span>
          </h2>
        </div>

        <div className="flex-1 overflow-y-auto p-8 lg:p-16 scrollbar-hide">
          {cart.length > 0 ? (
            <div className="space-y-6">
              {cart.map(cartItem => (
                <div key={cartItem.itemId} className="group relative flex items-center gap-6 p-6 bg-[#f8f7f2] transition-all duration-500" style={{ clipPath: 'polygon(0 0, 95% 0, 100% 20%, 100% 100%, 0 100%)' }}>
                  <div className="w-24 h-24 rounded-2xl bg-white flex items-center justify-center p-3 shadow-sm shrink-0 overflow-hidden">
                    <img src={getImageUrl(cartItem.image)} alt="" className="w-full h-full object-contain grayscale group-hover:grayscale-0 transition-all duration-700" />
                  </div>
                  
                  <div className="flex-1">
                    <p className="text-[10px] font-black text-[#94d600] uppercase tracking-widest mb-1">{cartItem.category || 'Strategic Asset'}</p>
                    <h4 className="text-xl font-bold text-[#0E7D83] uppercase tracking-tighter">{cartItem.name}</h4>
                    <button 
                      onClick={() => removeFromCart(cartItem.itemId)} 
                      className="text-[9px] text-red-400 hover:text-red-600 transition-colors mt-3 uppercase font-black tracking-widest flex items-center gap-1"
                    >
                      <X size={10} /> Remove
                    </button>
                  </div>

                  <div className="flex flex-col items-end gap-4">
                    <div className="flex items-center bg-white rounded-full p-1 border border-gray-100 shadow-sm">
                      <button onClick={() => updateCartQuantity(cartItem.itemId, cartItem.quantity - 1)} className="p-2 text-[#0E7D83] hover:bg-gray-50 rounded-full"><Minus size={12} /></button>
                      <span className="px-4 text-sm font-black text-[#0E7D83]">{cartItem.quantity}</span>
                      <button onClick={() => updateCartQuantity(cartItem.itemId, cartItem.quantity + 1)} className="p-2 text-[#0E7D83] hover:bg-gray-50 rounded-full"><Plus size={12} /></button>
                    </div>
                    <p className="text-lg font-bold text-[#0E7D83] tracking-tighter">
                      {(cartItem.price * cartItem.quantity).toLocaleString()} <span className="text-[10px] opacity-40">{currency}</span>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center py-20 opacity-10 text-[#0E7D83]">
               <Briefcase size={80} strokeWidth={1} className="mb-6" />
               <p className="text-xs font-black uppercase tracking-[0.5em]">Portfolio Empty</p>
            </div>
          )}
        </div>

        <div className="p-10 bg-white">
          <button 
            onClick={() => setIsCartOpen(false)}
            className="flex items-center gap-4 text-[#0E7D83] text-[10px] font-black uppercase tracking-[0.4em] group"
          >
            <ArrowLeft size={16} className="group-hover:-translate-x-2 transition-transform" /> Keep exploring services
          </button>
        </div>
      </div>

      {/* COLUNA DIREITA: Checkout & Protocol (Fixed/Scrollable) */}
      <div className="flex-1 bg-[#f8f7f2] p-10 lg:p-16 flex flex-col overflow-y-auto scrollbar-hide">
        <h3 className="text-[10px] font-black text-[#0E7D83] opacity-30 uppercase tracking-[0.5em] mb-12">Client Engagement Protocol</h3>
        
        <div className="flex-1 space-y-12">
          {/* Identificação */}
          <div className="grid grid-cols-1 gap-4">
            <div className="group">
              <label className="text-[9px] font-black uppercase text-[#0E7D83] ml-4 mb-2 block tracking-widest opacity-50">Entity / Full Name</label>
              <input placeholder="Ex: Global Solutions LDA" value={client.name} onChange={e => setClient({ ...client, name: e.target.value })} className="w-full px-8 py-5 bg-white border-none rounded-[1.5rem] text-sm font-bold text-[#0E7D83] focus:ring-2 ring-[#E5E65D] outline-none transition-all shadow-sm" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <input placeholder="Email" type="email" value={client.email} onChange={e => setClient({ ...client, email: e.target.value })} className="w-full px-8 py-5 bg-white border-none rounded-[1.5rem] text-sm font-bold text-[#0E7D83] focus:ring-2 ring-[#E5E65D] outline-none shadow-sm" />
              <input type='number' placeholder="Phone" value={client.phone} onChange={e => setClient({ ...client, phone: e.target.value })} className="w-full px-8 py-5 bg-white border-none rounded-[1.5rem] text-sm font-bold text-[#0E7D83] focus:ring-2 ring-[#E5E65D] outline-none shadow-sm" />
            </div>
            <textarea placeholder="Specific case notes..." rows={3} value={client.notes || ""} onChange={e => setClient({ ...client, notes: e.target.value })} className="w-full px-8 py-5 bg-white border-none rounded-[2rem] text-sm font-bold text-[#0E7D83] focus:ring-2 ring-[#E5E65D] outline-none shadow-sm resize-none" />
          </div>

          {/* Payment Selection */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#94d600]" />
              <label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#0E7D83]">Settlement Method</label>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {['mpesa', 'visa', 'emola', 'transfer'].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setPaymentMethod(m as any)}
                  className={`py-5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all duration-500 flex items-center justify-center gap-2 ${paymentMethod === m ? 'bg-[#0E7D83] text-[#E5E65D] shadow-2xl scale-[1.05]' : 'bg-white text-[#0E7D83] opacity-60 hover:opacity-100 shadow-sm'}`}
                >
                  {m === 'emola' ? 'e-Mola' : m === 'transfer' ? 'Bank Transfer' : m}
                  {paymentMethod === m && <Check size={12} strokeWidth={4} />}
                </button>
              ))}
            </div>
          </div>

          {/* Dados Bancários */}
          {paymentMethod === 'transfer' && (
            <div className="animate-in fade-in zoom-in-95 duration-500 p-8 bg-[#0E7D83] text-white rounded-[2.5rem] shadow-2xl">
              <h4 className="text-[10px] font-black uppercase tracking-widest mb-6 flex items-center gap-3 text-[#E5E65D]">
                <CreditCard size={16} /> Settlement Accounts
              </h4>
              <div className="space-y-6">
                {company.bankAccounts?.map((bank, idx) => (
                  <div key={idx} className="border-b border-white/10 pb-4 last:border-0">
                    <p className="text-xs font-black uppercase mb-3 text-[#94d600]">{bank.bankName}</p>
                    <div className="grid grid-cols-2 gap-4 text-[10px] font-mono opacity-80">
                      <div><p className="opacity-40 uppercase mb-1">Account</p><p className="font-bold">{bank.accountNumber}</p></div>
                      <div><p className="opacity-40 uppercase mb-1">NIB/IBAN</p><p className="font-bold">{bank.nibOrIban}</p></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Financial Summary & Actions */}
        <div className="mt-16 pt-10 border-t border-[#0E7D83]/10">
          <div className="flex justify-between items-center mb-10">
            <div>
              <span className="text-[10px] font-black text-[#94d600] uppercase tracking-widest block mb-2">Grand Total</span>
              <div className="text-6xl font-bold text-[#0E7D83] tracking-tighter">
                {totals.grandTotal.toLocaleString()} <span className="text-xl opacity-30 font-medium">{currency}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={handlePayment}
              // HABILITADO para mpesa, visa e emola
              disabled={!paymentMethod || !['mpesa', 'visa', 'emola'].includes(paymentMethod)}
              className="w-full py-6 bg-[#0E7D83] text-[#E5E65D] text-[11px] font-black uppercase tracking-[0.4em] rounded-full hover:bg-black transition-all shadow-2xl disabled:opacity-5 active:scale-95 flex items-center justify-center gap-3"
            >
              <Lock size={14} /> 
              {hasOrderWithPrice ? `Secure Payment (${totals.grandTotal.toLocaleString()})` : 'Initialize Gateway'}
            </button>

            <button
              onClick={handleSubmit}
              disabled={submitting || !client.name || !client.email || (hasOrderWithPrice && ['mpesa', 'visa', 'emola'].includes(paymentMethod))}
              className="w-full py-6 bg-white text-[#0E7D83] text-[11px] font-black uppercase tracking-[0.4em] rounded-full transition-all hover:bg-[#E5E65D] disabled:opacity-30 active:scale-95 shadow-md border border-[#0E7D83]/5"
            >
              {paymentMethod === 'transfer' ? 'Confirm Transfer Receipt' : 'Finalize Engagement Request'}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

{/* Success Modal - Estilo Axion Logistics (Clean & Corporate) */}
{showSuccessModal && (
  <div 
    className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-[#0E7D83]/60 backdrop-blur-md animate-in fade-in duration-500" 
    onClick={closeSuccessModal}
  >
    <div
      className="bg-white shadow-[0_40px_100px_rgba(0,0,0,0.4)] max-w-md w-full relative overflow-hidden transition-all transform scale-100"
      style={{ 
        borderRadius: '3rem',
        clipPath: 'polygon(0 0, 90% 0, 100% 10%, 100% 100%, 0 100%)' 
      }}
      onClick={e => e.stopPropagation()}
    >
      {/* Barra de Status Slim */}
      <div className="absolute top-0 left-0 w-full h-2 bg-[#94d600]" />
      
      <div className="p-8 md:p-12 text-center">
        {/* Ícone Reduzido e Integrado */}
        <div className="inline-flex items-center justify-center w-16 h-16 bg-[#f8f7f2] rounded-2xl mb-6 rotate-3">
          <div className="w-12 h-12 bg-[#0E7D83] rounded-xl flex items-center justify-center text-[#E5E65D] shadow-lg">
            <Check size={24} strokeWidth={4} />
          </div>
        </div>

        <div className="space-y-3 mb-8">
          <span className="text-[9px] font-black uppercase tracking-[0.4em] text-[#94d600] block">
            Confirmed Engagement
          </span>
          
          <h2 className="text-3xl font-bold text-[#0E7D83] leading-tight tracking-tightest uppercase">
            Order <span className="text-[#0E7D83]/30 italic font-serif lowercase">Successfully</span> Processed
          </h2>
          
          <p className="text-gray-400 text-[11px] leading-relaxed max-w-[280px] mx-auto font-bold uppercase tracking-tight">
            Sua solicitação foi registrada. Um e-mail de confirmação foi enviado para o seu endereço profissional.
          </p>
        </div>

        {/* Botão Principal Estilo Boutique */}
        <button
          onClick={closeSuccessModal}
          className="w-full py-5 bg-[#0E7D83] text-[#E5E65D] rounded-full transition-all hover:bg-black active:scale-95 font-black text-[10px] uppercase tracking-[0.3em] shadow-xl mb-8"
        >
          Return to Dashboard
        </button>
        
        {/* Footer Compacto (ID de Rastreio) */}
        <div className="pt-6 border-t border-dashed border-gray-100 flex flex-col items-center gap-2">
          <p className="text-[8px] font-black uppercase tracking-[0.2em] text-gray-300">
            Reference Protocol
          </p>
          <span className="font-mono text-sm font-bold text-[#0E7D83] tracking-[0.2em] bg-[#f8f7f2] px-4 py-1.5 rounded-lg border border-[#0E7D83]/5">
            #AX-{Math.random().toString(36).substr(2, 5).toUpperCase()}
          </span>
        </div>
      </div>
    </div>
  </div>
)}
<footer className="bg-[#0E7D83] pt-32 pb-12 overflow-hidden relative">
  {/* Detalhe Geométrico de Fundo - Grid de Engenharia */}
  <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
       style={{ backgroundImage: 'radial-gradient(#94d600 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

  <div className="max-w-7xl mx-auto px-6 relative z-10">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-16 mb-32">
      
      {/* Coluna 1: Branding e Newsletter Imersiva */}
      <div className="lg:col-span-4 space-y-12">
        <div className="flex items-center">
          {company.logo ? (
            <img src={company.logo} alt={company.name} className="h-10 w-auto brightness-0 invert" />
          ) : (
            <span className="font-bold text-2xl tracking-tighter text-white uppercase italic">
              /{company.name}<span className="text-[#94d600]">.</span>
            </span>
          )}
        </div>
        
        <p className="text-white/50 text-sm leading-relaxed max-w-xs font-medium">
          Líder global em inteligência estratégica e infraestrutura de alta performance. 
          Desenhando sistemas complexos com simplicidade absoluta.
        </p>
        
        {/* Newsletter Estilo "Command Line" */}
        <div className="space-y-4 pt-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#E5E65D]" />
            <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white">Strategic Intelligence</p>
          </div>
          <div className="flex p-1.5 bg-white/5 border border-white/10 rounded-2xl focus-within:border-[#E5E65D] transition-all backdrop-blur-sm">
            <input 
              type="email" 
              placeholder="Corporate email access" 
              className="flex-1 px-6 bg-transparent text-white text-xs outline-none placeholder:text-white/20 font-bold" 
            />
            <button className="px-8 py-3 bg-[#E5E65D] text-[#0E7D83] rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white transition-all shadow-xl">
              Subscribe
            </button>
          </div>
        </div>
      </div>

      {/* Coluna 2: Navegação com Estilo de Índice */}
      <div className="lg:col-span-2 space-y-10">
        <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#94d600]">Operations</h4>
        <ul className="space-y-5">
          {['Global Fleet', 'Tracking', 'Warehouse', 'Solutions'].map(link => (
            <li key={link}>
              <a href="#" className="text-[11px] text-white/40 hover:text-[#E5E65D] transition-all font-bold uppercase tracking-widest flex items-center gap-2 group">
                <span className="w-0 group-hover:w-4 h-[1px] bg-[#E5E65D] transition-all" />
                {link}
              </a>
            </li>
          ))}
        </ul>
      </div>

      {/* Coluna 3: Suporte Direto e Canais Críticos */}
      <div className="lg:col-span-3 space-y-10">
        <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#94d600]">Direct Access</h4>
        <ul className="space-y-10">
          <li className="flex flex-col gap-2">
            <span className="text-[9px] text-white/30 font-black uppercase tracking-[0.3em]">Hotline 24/7</span>
            <a href={`tel:${company.phone}`} className="text-white font-bold text-2xl hover:text-[#E5E65D] transition-colors tracking-tighter">
              {company.phone}
            </a>
          </li>
          <li className="flex flex-col gap-2">
            <span className="text-[9px] text-white/30 font-black uppercase tracking-[0.3em]">Official Liaison</span>
            <a href={`mailto:${company.email}`} className="text-[#94d600] font-bold text-sm hover:text-white transition-colors tracking-tight break-all">
              {company.email}
            </a>
          </li>
        </ul>
      </div>

      {/* Coluna 4: Presença Digital e Pagamentos */}
      <div className="lg:col-span-3 space-y-12">
        <div>
          <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#94d600] mb-8">Connect</h4>
          <div className="flex gap-4">
            {[Instagram, Facebook, Linkedin].map((Icon, idx) => (
              <a 
                key={idx} 
                href="#" 
                className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center text-white/40 hover:text-[#0E7D83] hover:bg-[#E5E65D] hover:border-[#E5E65D] transition-all duration-500"
              >
                <Icon size={18} />
              </a>
            ))}
          </div>
        </div>
        
        <div className="space-y-6">
           <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white/30">Cleared Protocols</p>
           <div className="flex flex-wrap gap-3">
              {['M-PESA', 'VISA', 'E-MOLA'].map(p => (
                <div key={p} className="px-4 py-2 border border-white/5 bg-white/[0.02] rounded-lg text-[9px] font-black text-white/40 hover:text-white hover:border-white/20 transition-all">
                  {p}
                </div>
              ))}
           </div>
        </div>
      </div>
    </div>

    {/* Bottom Bar: Certificações e Legal */}
    <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-12">
      <div className="space-y-3 text-center md:text-left">
        <p className="text-[10px] font-black text-white uppercase tracking-[0.4em]">
          © 2026 {company.name} <span className="text-white/20 font-medium">/ High-Stakes Infrastructure</span>
        </p>
        <div className="flex items-center justify-center md:justify-start gap-4 text-[9px] text-white/30 font-bold uppercase tracking-widest">
          <span>ISO 9001 CERTIFIED</span>
          <span className="w-1 h-1 rounded-full bg-white/10" />
          <span>GDPR COMPLIANT</span>
        </div>
      </div>
      
      <div className="flex gap-10">
        <a href="#" className="text-[9px] font-black text-white/40 hover:text-[#E5E65D] transition-colors uppercase tracking-[0.3em]">Privacy</a>
        <a href="#" className="text-[9px] font-black text-white/40 hover:text-[#E5E65D] transition-colors uppercase tracking-[0.3em]">Terms</a>
      </div>

      {/* System Status Dashboard Style */}
      <div className="flex items-center gap-4 px-8 py-3 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-md">
         <div className="relative flex h-2 w-2">
           <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#94d600] opacity-75"></span>
           <span className="relative inline-flex rounded-full h-2 w-2 bg-[#94d600]"></span>
         </div>
         <span className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Sytem Status: Operational</span>
      </div>
    </div>
  </div>
</footer>
    </div>
      </div>
  );
};

export default CuidadorPortal;